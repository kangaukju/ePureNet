<?php include "include/incs.php"; ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<head>
	<title> ȣ��Ʈ �׷� �߰� </title>
	<meta http-equiv="Content-Type" content="text/html; charset=euc-kr" />
	<script language="javascript" src="/js/common.js"></script>
	<link rel="stylesheet" href="/css/common.css" type="text/css" />
</head>

<body>
<input type="hidden" name="agent" value="<?=$_GET['agent']?>">
<table width="180px" border="0" cellpadding="0" cellspacing="0" align="center" class="pop_text">
<tr>
<td class="paddingT30">+ ��Ʈ��ũ ��ü ����</td>
</tr>
<tr>
<td class="paddingB10">
	<select name="netobj" class="selectbox">
		<option value="">����</option>
	<?php
	$table1=$_GET['agent']."_netobj";
	$netobj_list=mysql_query ("SELECT * FROM $table1", $connect);
	while ($netobj=@mysql_fetch_array ($netobj_list)) { 
		if ($_GET['netobj']==$netobj['netobj']) { ?>
			<option value="<?=$netobj['netobj']?>" selected><?=$netobj['netobj']?></option>
		<?php }
		else { ?>
			<option value="<?=$netobj['netobj']?>"><?=$netobj['netobj']?></option>
		<?php }
	} ?>
	</select>
</td>
</tr>
<tr>
<td>+ ȣ��Ʈ �׷� �߰�</td>
</tr>
<tr>
<td><input type="text" id="host" value="" />&nbsp;<input type="submit" value="�߰�" onclick="host_add();" /></td>
</tr>
</body>
</html>