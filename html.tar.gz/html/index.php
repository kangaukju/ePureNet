<?php include "include/inc.php"; ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<head>
	<title> ePureNet :: �α��� </title>
	<meta http-equiv="Content-Type" content="text/html; charset=euc-kr" />
	<script language="javascript" src="/js/common.js"></script>
	<link rel="stylesheet" href="/css/common.css" type="text/css" />
</head>

<body>
	<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0" valign="middle" bgcolor="#4c4c4c">
	<tr>
	<td>
		<!-- �α��� �ڽ� S -->
		<table width="500px" height="300px" border="0" cellpadding="0" cellspacing="0" align="center" class="log_in_box">
		<tr>
		<td class="log_in_top"></td>
		</tr>
		<tr>
		<td>
			<form id="form">
			<table border="0" cellpadding="0" cellspacing="0" class="log_in_cen">
			<tr>
			<td align="center" valign="top" class="log_in_tit"><img src="img/tit_login.gif" alt="������ �α���" /></td>
			</tr>
			<tr>
			<td valign="top" align="center">
				<table border="0" cellpadding="3" cellspacing="0">
				<tr>
				<td align="right"><img src="img/stit_ip.gif" alt="ip address" /></td>
				<td><input type="text" id="ip" /></td>
				<td rowspan="3"><img src="img/btn_login.gif" alt="log-in" class="img_cursor"  onclick="return login_check();" /></td>
				<tr>
				<td align="right"><img src="img/stit_logid.gif" alt="id" /></td>
				<td><input type="text" id="id" /></td>
				</tr>
				<tr>
				<td align="right"><img src="img/stit_logpass.gif" alt="password" /></td>
				<td><input type="password" id="pass" /></td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
			</form>
		</td>
		</tr>
		<tr>
		<td class="log_in_bot"></td>
		</tr>
		</table>
		<!-- �α��� �ڽ� E -->
	</td>
	</tr>
	</table>
</body>
</html>