<?php include "include/incs.php";

$table=$_POST['agent']."_group";
mysql_query ("UPDATE $table SET host='$_POST[host]' WHERE host='$_POST[R_host]'", $connect);
?>