<?php include "header.php"; 
$database=$_GET['agent'];

$connect=mysql_connect ($mysql_server, $db_user, $db_password);
mysql_select_db($database, $connect) or die ("agent�� �����ϼ���");

$result=mysql_query ("SELECT * FROM $_GET[agent].live", $connect);
//$result=mysql_query ("SELECT distinct src_ip, dest_ip, time  FROM $_GET[agent].live group by src_ip, dest_ip, time order by time", $connect);

$filename="List_live.csv";
$csv_cont.="No,�����IP,��Ʈ,������IP,��Ʈ,url,��¥,�ð�\n";
$i=1;
while ($temp=@mysql_fetch_array ($result)) {
  $item1=$i;
  $item2=$temp['src_ip'];
  $item3=$temp['src_port'];
  $item4=$temp['dest_ip'];
  $item5=$temp['dest_port'];
  $item6=$temp['url'];
  $item7=$temp['date'];
  $item8=$temp['time'];
  $csv_cont.=$item1.",".$item2.",".$item3.",".$item4.",".$item5.",".$item6.",".$item7.",".$item8."\n"; 
  $i++;
}
$fp = fopen("excel/$filename","w") ;
fwrite($fp,$csv_cont) ;
fclose($fp) ;
?>
<table width="760px" border="0" cellpadding="0" cellspacing="0" class="bg_center">
<tr>
<td valign="top" class="paddingT10L10"><a href="excel/<?=$filename?>" target="_blank"><img src="img/btn_excel.gif" alt="������ �����ϱ�" /></a></td>
</tr>
</table>

<?php include "footer.php"; ?>
