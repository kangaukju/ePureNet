
<!-- ��å content S -->
<table width="920px" border="0" cellpadding="0" cellspacing="0" class="sm_box_on" id="main_1">
<tr>
<td width="200px" valign="top">
	<!-- left menu S -->
	<table width="200px" border="0" cellpadding="0" cellspacing="0" class="left_box">
	<tr>
	<td class="left_top"></td>
	</tr>
	<tr>
	<td class="left_cen" valign="top">
		<table width="100%" border="0" cellpadding="0" cellspacing="0" class="left_menu1">
		<tr>
		<td height="30px" align="center" valign="top"><img src="img/tit_left1.gif" alt="�����" /></td>
		</tr>
		<tr>
		<td valign="top" align="center">
			<select id="left1" class="select" onchange="all_or(this.value);">
				<option value="all">��ü����</option>
				<option value="agent1">agent1</option>
				<option value="agent2">agent2</option>
				<option value="agent3">agent3</option>
				<option value="agent4">agent4</option>
				<option value="agent5">agent5</option>
			</select>
		</td>
		</tr>
		</table>

		<table width="100%" border="0" cellpadding="0" cellspacing="0" class="left_menu2">
		<tr>
		<td><strong>[master]</strong></td>
		</tr>
		<tr>
		<td><strong>IP</strong> : 211.221.225.32</td>
		</tr>
		<tr>
		<td><strong>�̸�</strong> : DB ����</td>
		</tr>
		<tr>
		<td><strong>����</strong> : ����� ����û</td>
		</tr>
		<tr>
		<td><strong>������</strong> : ȫ�浿</td>
		</tr>
		<tr>
		<td><strong>E-mail</strong> : aaa@nate.com</td>
		</tr>
		<tr>
		<td><strong>phone</strong> : 010.1111.1111</td>
		</tr>
		</table>
	</td>
	</tr>
	<tr>
	<td class="left_bot"></td>
	</tr>
	</table>
	<!-- left menu E -->
</td>
<td width="700px" class="sub_tab" valign="top">
	<!-- ��å subtab S -->
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
	<td width="80px" height="30px" align="center" class="mtit_on" id="mtit1" onclick="subtab('1', 'mtit_', 'submain_', '3', 'mtit');"><img src="img/mtit_1_on.gif" alt="��å" id="mtit_1" /></td>
	<td width="80px" height="30px" align="center" class="mtit_off" id="mtit2" onclick="subtab('2', 'mtit_', 'submain_', '3', 'mtit');"><img src="img/mtit_2_off.gif" alt="��ü ����" id="mtit_2" /></td>
	<td class="m_tab">&nbsp;</td>
	</tr>
	</table>
	<!-- ��å subtab E -->

	<!-- ��å S -->
	<table width="100%" border="0" cellpadding="0" cellspacing="0" id="submain_1">
	<tr>
	<td valign="top">
		<table border="0" cellpadding="0" cellspacing="0" class="date_box">
		<tr>
		<td height="40px" valign="top" class="marginTop"><img src="img/tit_time.gif" alt="�ð�����" /></td>
		</tr>
		<tr>
		<td valign="top">
			<table border="0" cellpadding="0" cellspacing="0" class="day_box">
			<tr>
			<td><strong>���� ����</strong></td>
			</tr>
			<tr>
			<td valign="top" class="day_boxtd">
				<input type="checkbox" id="sun" class="check_input" /><label for="sun">SUN</label>
				<input type="checkbox" id="mon" class="check_input" /><label for="mon">MON</label>
				<input type="checkbox" id="tue" class="check_input" /><label for="tue">TUE</label>
				<input type="checkbox" id="web" class="check_input" /><label for="web">WEB</label>
				<input type="checkbox" id="thr" class="check_input" /><label for="thr">THR</label>
				<input type="checkbox" id="fri" class="check_input" /><label for="fri">FRI</label>
				<input type="checkbox" id="sat" class="check_input" /><label for="sat">SAT</label>
			</td>
			</tr>
			</table>
		</td>
		</tr>
		<tr>
		<td valign="top">
			<table border="0" cellpadding="0" cellspacing="0" class="day_box">
			<tr>
			<td><strong>�ð� ����</strong></td>
			</tr>
			<tr>
			<td valign="top" class="day_boxtd">
				<table border="0" cellpadding="0" cellspacing="0" class="time_box">
				<tr>
				<td>
					<input type="checkbox" id="01" class="check_input" /><label for="01">0~1</label>
				</td>
				<td>
					<input type="checkbox" id="12" class="check_input" /><label for="12">1~2</label>
				</td>
				<td>
					<input type="checkbox" id="23" class="check_input" /><label for="23">2~3</label>
				</td>
				<td>
					<input type="checkbox" id="34" class="check_input" /><label for="34">3~4</label>
				</td>
				<td>
					<input type="checkbox" id="45" class="check_input" /><label for="45">4~5</label>
				</td>
				<td>
					<input type="checkbox" id="56" class="check_input" /><label for="56">5~6</label>
				</td>
				</tr>
				<tr>
				<td>
					<input type="checkbox" id="67" class="check_input" /><label for="67">6~7</label>
				</td>
				<td>
					<input type="checkbox" id="78" class="check_input" /><label for="78">7~8</label>
				</td>
				<td>
					<input type="checkbox" id="89" class="check_input" /><label for="89">8~9</label>
				</td>
				<td>
					<input type="checkbox" id="910" class="check_input" /><label for="910">9~10</label>
				</td>
				<td>
					<input type="checkbox" id="1011" class="check_input" /><label for="1011">10~11</label>
				</td>
				<td>
					<input type="checkbox" id="1112" class="check_input" /><label for="1112">11~12</label>
				</td>
				</tr>
				<tr>
				<td>
					<input type="checkbox" id="1213" class="check_input" /><label for="1213">12~13</label>
				</td>
				<td>
					<input type="checkbox" id="1314" class="check_input" /><label for="1314">13~14</label>
				</td>
				<td>
					<input type="checkbox" id="1415" class="check_input" /><label for="1415">14~15</label>
				</td>
				<td>
					<input type="checkbox" id="1516" class="check_input" /><label for="1516">15~16</label>
				</td>
				<td>
					<input type="checkbox" id="1617" class="check_input" /><label for="1617">16~17</label>
				</td>
				<td>
					<input type="checkbox" id="1718" class="check_input" /><label for="1718">17~18</label>
				</td>
				</tr>
				<tr>
				<td>
					<input type="checkbox" id="1819" class="check_input" /><label for="1819">18~19</label>
				</td>
				<td>
					<input type="checkbox" id="1920" class="check_input" /><label for="1920">19~20</label>
				</td>
				<td>
					<input type="checkbox" id="2021" class="check_input" /><label for="2021">20~21</label>
				</td>
				<td>
					<input type="checkbox" id="2122" class="check_input" /><label for="2122">21~22</label>
				</td>
				<td>
					<input type="checkbox" id="2223" class="check_input" /><label for="2223">22~23</label>
				</td>
				<td>
					<input type="checkbox" id="2324" class="check_input" /><label for="2324">23~24</label>
				</td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
		</td>
		</tr>
		</table>
	</td>
	<td valign="top" align="right">
		<table border="0" cellpadding="0" cellspacing="0" class="date_box">
		<tr>
		<td height="40px" valign="top" class="marginTop"><img src="img/tit_cut.gif" alt="���ܼ���" /></td>
		</tr>
		<tr>
		<td valign="top">
			<table border="0" cellpadding="5" cellspacing="0" class="cut_box">
			<tr>
			<th>����</th>
			<th style="border-right:1px solid #808080;">����</th>
			</tr>
			<tr>
			<td>URL</td>
			<td><input type="text" id="url" class="text_input150" /><img src="img/btn_add.gif" alt="�߰�" /><img src="img/btn_del.gif" alt="����"/></td>
			</tr>
			<td>IP ADDRESS</td>
			<td><input type="text" id="ipaddress" class="text_input150" /><img src="img/btn_add.gif" alt="�߰�" /><img src="img/btn_del.gif" alt="����"/></td>
			</tr>
			</tr>
			<td>KEYWORD NAME</td>
			<td><input type="text" id="keywordname" class="text_input150" /></td>
			</tr>
			</tr>
			<td>KEYWORD CONTENT</td>
			<td><textarea id="keywordcontent" class="textarea" /></textarea><img src="img/btn_add.gif" alt="�߰�" /><img src="img/btn_del.gif" alt="����"/></td>
			</tr>
			<tr>
			<th colspan="2" style="border-right:1px solid #808080;">����������</th>
			</tr>
			<tr>
			<td colspan="2"><input type="text" id="cutpage" class="text_input220" /><img src="img/btn_add.gif" alt="�߰�" /><img src="img/btn_del.gif" alt="����"/></td>
			</tr>
			</table>
		</td>
		</tr>
		</table>
	</td>
	</tr>
	<tr>
	<td colspan="2">
		<table border="0" cellpadding="0" cellspacing="0" class="bottom_box">
		<tr>
		<td>
			<?php include "url.php"; ?>
			<?php include "ip.php"; ?>
			<?php include "keyword.php"; ?>
			<?php include "cut.php"; ?>
		</td>
		</tr>
		</table>
	</td>
	</tr>
	</table>
	<!-- ��å E -->

	<!-- ���� S -->
	<table width="100%" border="0" cellpadding="0" cellspacing="0" id="submain_2" style="display:none;">
	<tr>
	<td>����</td>
	</tr>
	</table>
	<!-- ���� E -->
</td>
</tr>
</table>
<!-- ��å content E -->
<!-- LOG content S -->
<table width="920px" border="0" cellpadding="0" cellspacing="0" class="sm_box_on" id="main_2" style="display:none;">
<tr>
<td>LOG</td>
</tr>
</table>
<!-- LOG content E -->
<!-- �ǽð� content S -->
<table width="920px" border="0" cellpadding="0" cellspacing="0" class="sm_box_on" id="main_3" style="display:none;">
<tr>
<td>�ǽð�</td>
</tr>
</table>
<!-- �ǽð� content E -->
