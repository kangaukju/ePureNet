<?php include "include/incs.php";

$table=$_POST['agent']."_netobj";
$table2=$_POST['agent']."_group";
$table3=$_POST['agent']."_policy";
mysql_query ("DELETE FROM $table WHERE netobj='$_POST[R_netobj]'", $connect);
mysql_query ("DELETE FROM $table2 WHERE netobj='$_POST[R_netobj]'", $connect);
mysql_query ("DELETE FROM $table3 WHERE netobj='$_POST[R_netobj]'", $connect);
?>