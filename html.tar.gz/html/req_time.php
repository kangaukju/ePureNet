<?php
if( $_POST['agent'] && $_POST['ip'] && $_POST['port'] && $_POST['year'] && $_POST['mon'])
{	
	$port = $_POST['port'];
	$dest= $_POST['ip'];
	
	$value=explode("agent", $_POST['agent']);
	
	$REQ = "TIME".$value[1]."-".$_POST['year']."-".$_POST['mon']."\0";
	$recv_data;
	$start_time;
	$end_time;
	
	$start_time = date('is');
	

  if(false === $socket = @socket_create(AF_INET, SOCK_STREAM, 0))
  {
		echo "socket create error<br>";	// !!!!!!!!����!!!!!!!!!!!!!!
	}
	else
	{		
		if(false === @socket_connect($socket, $dest, $port))
		{
			echo "socket_connect error<br>";	// !!!!!!!!����!!!!!!!!!!!!!!
		}
		else
		{			
			if(false === @socket_write ($socket, $REQ, 13))
			{
				echo "socket_write error<br>";	// !!!!!!!!����!!!!!!!!!!!!!!
			}
			else
			{
				socket_set_block($socket);
				$recv_data = socket_read ($socket, 10);
				
				
				if($recv_data[0] != 'n')
				{
					echo $recv_data;	// !!!!!!!!����!!!!!!!!!!!!!!
				}
				else
				{
					echo "No";	// !!!!!!!!����!!!!!!!!!!!!!!
				}
			}
		}
	}
}

else{

	echo "No";
}

?>
