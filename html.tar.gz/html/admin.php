<?php include "header.php"; 
$member=@mysql_fetch_array (mysql_query ("SELECT * FROM member", $connect)); ?>
<table width="760px" border="0" cellpadding="0" cellspacing="0" class="bg_center">
<tr>
<td valign="top" class="paddingT10L10">
	<form name="form" method="post" action="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&mode=change" onsubmit="return pass_check();">
	<table width="350px" border="0" cellpadding="5" cellspacing="0" class="A_table">
	<tr>
	<th>IP ADDRESS</th>
	<td><input type="text" name="ip" value="<?=$member['ip']?>" class="search_input" /></td>
	</tr>
	<tr>
	<th>ID</th>
	<td><input type="text" name="id" value="<?=$member['name']?>" class="search_input" /></td>
	</tr>
	<tr>
	<th>PASSWORD</th>
	<td><input type="text" name="pass" value="" class="search_input" /></td>
	</tr>
	<tr>
	<th>RE PASSWORD</th>
	<td><input type="text" name="re_pass" value="" class="search_input" /></td>
	</tr>
	<tr>
	<th>PHONE NUMBER</th>
	<td><input type="text" name="phone" value="<?=$member['phone']?>" class="search_input" /></td>
	</tr>
	<tr>
	<td colspan="2" align="center"><input type="submit" value="����" class="search_submit" /></td>
	</tr>
	</table>
	</form>
</td>
</tr>
</table>
<?php include "footer.php"; 
if ($_GET['mode']=="change") {
	if ($_POST['pass']) {
		$password=md5($_POST['pass']);
		mysql_query ("UPDATE member SET pass='$password'", $connect);
	}
	else {
	}
	mysql_query ("UPDATE member SET ip='$_POST[ip]', name='$_POST[id]', phone='$_POST[phone]'", $connect);
	echo "<script>location.replace('admin.php?agent=".$_GET['agent']."');</script>";
} ?>