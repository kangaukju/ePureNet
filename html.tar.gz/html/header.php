<?php include "include/inc.php"; ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<head>
	<title>ePureNet</title>
	<meta http-equiv="Content-Type" content="text/html; charset=euc-kr" />
	<script language="javascript" src="/js/common.js"></script>
	<script language="Javascript" src="FusionCharts.js"></script>
	<link rel="stylesheet" href="/css/common.css" type="text/css" />
</head>

<body>
<div id="no_tu" style="display:none;"></div>
<table width="100%" border="0" cellpadding="0" cellspacing="0" class="main" align="center">
<tr>
<td>
	<span class="logo"><a href="main.php"><img src="img/logos.jpg" alt="logo"></a></span>
	<span class="descript">ePureNet</span>
</td>
</tr>
<tr>
<td width="100%"class="txt_log">
	<span class="paddingT5"><strong><?=$id?></strong> �� �α��� ���Դϴ�.&nbsp;&nbsp;</span>
	<span><img src="img/btn_logout.gif" alt="log out" onclick="logout_check();" /></span>
</td>
</tr>
<tr>
<td class="paddingT18L100">
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
	<td width="130px" class="cursor"><img src="img/tit_1.gif" alt="��Ʈ�� Ʈ����" onmouseover="main_tab('1');" /></td>
	<td width="135px" class="cursor"><img src="img/tit_2.gif" alt="�ǽð� ����͸�" onmouseover="main_tab('2');" /></td>
	<td width="135px" class="cursor" onmouseover="main_clear();"><a href="status.php?agent=<?=$_GET['agent']?>"><img src="img/tit_3.gif" alt="���� ����" /></a></td>
	<td width="135px" class="cursor" onmouseover="main_clear();"><a href="police.php?agent=<?=$_GET['agent']?>&where=url"><img src="img/tit_4.gif" alt="��å ����" /></td>
	<td class="cursor" onmouseover="main_clear();"><a href="admin.php?agent=<?=$_GET['agent']?>"><img src="img/tit_6.gif" alt="������ ����" /></a></td>
	</tr>
	</table>
</td>
</tr>
<tr>
<td class="paddingB10">
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
	<td width="157px" valign="top" class="paddingL20T20">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		<tr>
		<td align="center"><img src="img/ltit_agent.gif" alt="select agent" /></td>
		</tr>
		<tr>
		<td align="center">
			<select id="select_agent" onchange="location.replace('<?=$_SERVER['PHP_SELF']?>?agent='+this.value);">
				<option value="">��� ����</option>
				<?php
				$agent_query=mysql_query ("SHOW DATABASES", $connect);
				while ($agent=@mysql_fetch_array($agent_query)) {
					if(strstr($agent[0], "agent")){
						if ($_GET['agent']==$agent[0]) {
							echo '<option value="'.$agent[0].'" selected>'.$agent[0].'</option>';
						}
						else {
							echo '<option value="'.$agent[0].'">'.$agent[0].'</option>';
						}
					}
				} ?>
			</select>
		</td>
		</tr>
		<!-- left agent selectbox E -->
		<!-- left agent list S -->
		<tr>
		<td align="center" class="paddingB10"><img src="img/ltit_list.gif" alt="agent list" /></td>
		</tr>
		<tr>
		<td align="center">
			<div id="left">
				<table width="140px" border="0" cellpadding="1" cellspacing="0" class="left_list">
				<tr>
				<th width="80px" class="borderR">Name</th>
				<th width="60px">Status</th>
				</tr>
				</table>
			</div>
			<script>setTimeout("left('<?=$sms?>')", 3000);</script>
		</td>
		</tr>
		</table>
	</td>
	<td width="715px" valign="top">
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		<tr>
		<td class="sub_title" height="40px">
			<span id="sub_1" style="display:none;">
				<a href="P1_log_be.php?agent=<?=$_GET['agent']?>"><img src="img/stit_1s.gif" alt="���� �α� �˻�" /></a>
				<a href="P1_log.php?agent=<?=$_GET['agent']?>"><img src="img/stit_1.gif" alt="�α� �˻�" /></a>
				<a href="P1_graph.php?agent=<?=$_GET['agent']?>"><img src="img/stit_2.gif" alt="�׷���" /></a>
				<a href="P1_report.php?agent=<?=$_GET['agent']?>"><img src="img/stit_3.gif" alt="������" /></a>
			</span>
			<span id="sub_2" style="display:none;">
				<a href="P2_log.php?agent=<?=$_GET['agent']?>"><img src="img/stit_1.gif" alt="�α� �˻�" /></a>
				<a href="P2_graph.php?agent=<?=$_GET['agent']?>"><img src="img/stit_2.gif" alt="�׷���" /></a>
				<a href="P2_report.php?agent=<?=$_GET['agent']?>""><img src="img/stit_3.gif" alt="������" /></a>
			</span>
		</td>
		</td>
		</tr>
		<tr>
		<td>