<?php include "include/incs.php";

$table=$_POST['agent']."_policy";
mysql_query ("DELETE FROM $table WHERE netobj='$_POST[netobj]' AND no='$_POST[no]'", $connect);
?>