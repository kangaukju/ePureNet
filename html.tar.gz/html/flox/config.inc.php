<?php

/**
 * Copyright 2006 Sven Anderson <sven-flox@anderson.de>
 *
 * This file is part of FloX.
 *
 * FloX is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * FloX is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FloX; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

$dbType = "mysql";     /* name of PEAR-DB database backend, like pgsql,
                          mysql or sqlite */
$dbHost = "localhost"; /* database hostname */
$dbPort = "";          /* database port (leave empty for default) */
$dbName = "pmacct";    /* database name */
$dbUser = "pmacct";    /* database username */
$dbPass = "pmacct";   /* database password */

$hideTables = array(   /* list of tables, which should not be displayed */
	"acct_as_v5",
	"acct_uni_v5",
	"proto"
);

$counterFields = array( /* list of columns, which contain counter fields */
	"bytes",
	"packets",
	"flows"
);

$timeField = "stamp_inserted"; /* which column contains the timestamps used 
                                  for time slot selection */

$timeFormat = "Y-m-d H:i:s";   /* format of the timestamps (in PHP style) */

?>
