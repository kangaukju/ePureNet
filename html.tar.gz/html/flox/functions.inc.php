<?php

/**
 * Copyright 2006 Sven Anderson <sven-flox@anderson.de>
 *
 * This file is part of FloX.
 *
 * FloX is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * FloX is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FloX; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

require_once('config.inc.php');
require_once('DB.php');

/**
 * init stuff 
 */

$version = "0.1.1";
$tableNames = array();
$keyNames = array();
$counters = array();
$PHP_SELF = $_SERVER['PHP_SELF'];

/* array of setting parameters */
$set = array();

/* array of parameters for flow key conditions */ 
$keyCond = array();

/* connect to database */
$db = DB::connect("${dbType}://${dbUser}:${dbPass}@${dbHost}:${dbPort}/${dbName}");
if (DB::isError($db)) die($db->getMessage());

/* load table names in $tableNames*/
setTableNames();

/* load $keyNames and existing $counters */
if (isset($_GET['table']) && in_array($_GET['table'], $tableNames)) { 
	$set['table'] = $_GET['table'];
	setKeyNames();
}

/* check $counterFields for nonexisting fields */
//foreach ($counterFields as $k => $v) if (! in_array($v, $keyNames))
//	array_splice($counterFields, $k);

/* fill up $set with values from $_GET or defaults */
$time = gettimeofday();
$set['start'] = ( isset($_GET['start']) ? $_GET['start']
	: date($timeFormat,$time['sec']-3600) );
$set['end'] = ( isset($_GET['end']) ? $_GET['end']
	: date($timeFormat,$time['sec']) );
$set['len'] = ( isset($_GET['len']) ? $_GET['len']
	: 10 );
$set['orderby'] = ( isset($_GET['orderby']) && 
	in_array($_GET['orderby'],$counters) ? $_GET['orderby']
	: $counters[0] );
$set['sumby'] = ( isset($_GET['sumby']) &&
	in_array($_GET['sumby'],$keyNames) ? $_GET['sumby']
	: null );
$set['sqlcond'] = ( isset($_GET['sqlcond']) ? $_GET['sqlcond'] : null );

/* fill up $keyCond with values from $_GET */
foreach ($_GET as $k => $v) if (in_array($k, $keyNames)) $keyCond[$k] = $v;


/**
 * setTableNames()
 * sets $tableNames to all available tables (cleaned up with $hideTables)
 */
function setTableNames() {
	global $db,$hideTables,$tableNames;
	$tableNames=array();
	$r = $db->getListOf('tables');
	if (DB::isError($r)) die("setTableNames(): " . $r->getMessage());
	foreach ($r as $v) if (! in_array($v, $hideTables))
		array_push($tableNames, $v);
}

/**
 * setKeyNames()        
 * set $keyNames to all available flow key names in $set['table'].
 */
function setKeyNames() {
	global $db,$counterFields,$counters,$timeField,$keyNames,$set;
	$keyNames = array();
	$counters = array();
	$names = array();
	$q = $db->query("SELECT * FROM " . dq($set['table']) . " LIMIT 0");
	if (DB::isError($q)) die("setKeyNames(): " . $q->getMessage());
	$info = $db->tableInfo($q);
	foreach ($info as $v) {
		array_push($names, $v['name']);
		if (! in_array($v['name'], $counterFields))
//			if ($timeField != $v['name'])
				array_push($keyNames, $v['name']);
	}
	/* fill $counters with existing $counterFields in same order */
	foreach ($counterFields as $v) if (in_array($v, $names))
		array_push($counters, $v);
}

/**
 * tableList()
 * prints a list with <li> tags for all tables. All items have links with
 * the table variable set, except for item $set['table'], if set.
 */
function tableList() {
	global $PHP_SELF,$tableNames,$set;
	foreach ($tableNames as $v) {
		echo "<li>";
		if (!isset($set['table']) || $v != $set['table']) {
			echo "<a href=\"$PHP_SELF?table=$v\">$v</a>";
		} else {
			echo "$v";
		}
		echo "</li>\n";
	}
}

/**
 * keyList()
 * prints a list with <li> tags for all keys. If no value is assigned by
 * $keyCond, it has a link to the according sum page. Else the given
 * value is shown and it has a link removing that value.
 */
function keyList() {
	global $keyNames,$keyCond;
	foreach ($keyNames as $v) {
		echo "<li><a href=\"";
		if (isset($keyCond[$v])) {
			echo getLink(array($v => null, 'sumby' => null));
			echo "\">$v</a>: $keyCond[$v]";
		} else {
			echo getLink(array('sumby' => $v));
			echo "\">$v</a>";
		}
		echo "</li>\n";
	}
}

/**
 * getLink($values)
 * create and return a link with parameters based on $keyCond and $set and
 * $modified by values.
 */
function getLink($values) {
	global $PHP_SELF, $keyCond, $set;
	$a = array();
	$tmp = array_merge($set, $keyCond, $values);
	foreach($tmp as $k => $v) if (isset($v))
		 array_push($a, rawurlencode($k) . "=" . rawurlencode($v));
	if (count($a)) return("$PHP_SELF?" . implode("&", $a));
	return($PHP_SELF);
}

/**
 * hiddenInput($values)
 * print hidden input fields based on $keyCond and $set and modified by
 * values.
 */
function hiddenInput($values) {
	global $keyCond, $set;
	$tmp = array_merge($set, $keyCond, $values);
	foreach($tmp as $k => $v) if (isset($v))
		echo "<input type=\"hidden\" name=\"$k\" value=\"$v\" />\n";
}

/**
 * selectedOptions($select, $values)
 * print <option> list of array $values, with $select preselected.
 */
function selectedOptions($select, $values) {
	foreach($values as $v) {
		echo "<option ";
		if ($v == $select) echo "selected=\"selected\"";
		echo ">$v</option>\n";
	}
}


/**
 * sumTable()
 * prints the summation ranking in a table.
 */
function sumTable() {
	global $counters,$set,$timeField,$keyCond,$db;
	$sql = "SELECT " . dq($set['sumby']);
	foreach($counters as $v) $sql .= ",SUM(" . dq($v) . ")";
	$sql .= " FROM " . dq($set['table']);
	$sql .= " WHERE " . dq($timeField) . ">=" . sq($set['start']);
	$sql .= " AND " . dq($timeField) . "<" . sq($set['end']);
	foreach($keyCond as $k => $v)
		$sql .= " AND " . dq($k) . "=" . sq($v);
	if (isset($set['sqlcond']) && $set['sqlcond'] != "")
		$sql .= " AND ( " . $set['sqlcond'] . " )";
	$sql .= " GROUP BY " . dq($set['sumby']);
	$sql .= " ORDER BY SUM(" . dq($set['orderby']) . ") DESC";
	$sql .= " LIMIT " . intval($set['len']);
	$q = $db->query($sql);
	if (DB::isError($q)) die("sumTable(): " . $q->getMessage());
	echo "<tr><th>" . $set['sumby'] . "</th>";
	foreach($counters as $v) echo "<th>" . $v . "</th>";
	echo "</tr>\n";
	while ($q->fetchInto($row)) {
		echo "<tr>";
		foreach($row as $v) echo "<td>$v</td>";
		echo "<td><a href=\""
			. getLink(array($set['sumby']=>$row[0],"sumby"=>null))
			. "\">select</a></td></tr>\n";
	}
}

/**
 * sq($string)
 * return $string with all ' doubled and ' added before and after.
 */
function sq($string) {
	return("'" . str_replace("'", "''", $string) . "'");
}

/**
 * dq($string)
 * return $string with all " doubled and " added before and after.
 */
function dq($string) {
	global $dbType;
	if ($dbType == "mysql")
		return(str_replace(" ", "_", $string));
	return("\"" . str_replace("\"", "\"\"", $string) . "\"");
}


?>