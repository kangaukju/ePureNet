<?php include "include/incs.php";

$table=$_POST['agent']."_policy";
if ($_POST['where']=="url") {
	$type='1';
}
else if ($_POST['where']=="keyword") {
	$type='2';
}
else if ($_POST['where']=="ip") {
	$type='3';
}
mysql_query ("DELETE FROM $table WHERE netobj='$_POST[netobj]' AND catagory='$_POST[value]' AND type='$type'", $connect);
?>