
</style>
<style type="text/css">
			<!--
			td {
					font-family: Arial, Helvetica, sans-serif;
					font-size: 14px;
					text-align:center;
		
			}

			 A:hover {text-decoration: none; color:orange} 
			 A:visited{text-decoration:none; color:blue;}
			 A{text-decoration: none; color:black;}

} 

			-->
</style>


<html>
<head>

<head>


<body bgcolor="#D9EEFD">


<table>
	<tr height=30>
		<td></td>
	</tr>

	<td align=center>
	<b><hr><font color=red>TOTAL</font></b><hr>
	</td>
<tr>
<tr align="center" height="20" onMouseOver="this.style.backgroundColor='#CCCCCC'" onMouseOut="this.style.backgroundColor='#CCFFFF'">
	<td>
	<!--	<a href='javascript:move_page("./body.php?mode=1")'><b> ALL VIEW</b></a> -->
		<li><a href='./body.php?mode=DB' target=pbody><b> ���� ����</b></a>

	</td>
</tr>
		
<tr height=60>
	<td>
	</td>
</tr>
<tr>
	<td align=center>	
	<hr><b><font color=red>LIVE</font></b><hr>
	</td>
</tr>
<tr align="center" height="20" onMouseOver="this.style.backgroundColor='#CCCCCC'" onMouseOut="this.style.backgroundColor='#CCFFFF'">
	<td>
		<li><a href='./body.php?mode=LIVE' target=pbody><b> �ǽð� ����<b></a>
	</td>
</tr>
<tr height=60>
	<td>
	</td>
</tr>
<tr>
	<td align=center>	
	<hr><b><font color=red>TRAFFIC</font></b><hr>
	</td>
</tr>
<tr align="center" height="20" onMouseOver="this.style.backgroundColor='#CCCCCC'" onMouseOut="this.style.backgroundColor='#CCFFFF'">
	<td>
		<li><a href='./traffic/traffic.php' target=pbody><b> Ʈ���� ����<b></a>
	</td>
</tr>


</form>
</body>
</html>
