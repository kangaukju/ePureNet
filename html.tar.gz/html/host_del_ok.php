<?php include "include/incs.php";

$table=$_POST['agent']."_group";
mysql_query ("DELETE FROM $table WHERE host='$_POST[R_host]'", $connect);
?>