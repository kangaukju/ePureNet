<?php include "include/incs.php"; ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<head>
	<title> ��Ʈ��ũ ��ü �߰� </title>
	<meta http-equiv="Content-Type" content="text/html; charset=euc-kr" />
	<script language="javascript" src="/js/common.js"></script>
	<link rel="stylesheet" href="/css/common.css" type="text/css" />
</head>

<body>
<input type="hidden" name="agent" value="<?=$_GET['agent']?>">
<table width="180px" border="0" cellpadding="0" cellspacing="0" align="center" class="pop_text">
<tr>
<td class="paddingT30">+ ��Ʈ��ũ ��ü �߰�</td>
</tr>
<tr>
<td><input type="text" id="netobj" value="" />&nbsp;<input type="submit" value="�߰�" onclick="netobj_add();" /></td>
</tr>
</body>
</html>