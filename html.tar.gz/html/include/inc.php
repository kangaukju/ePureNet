<?php
$mysql_server='211.221.225.34';
$database='information';
$db_user='root';
$db_password='1234';
$port = 9000;

$connect = mysql_connect ($mysql_server, $db_user, $db_password);
mysql_select_db($database, $connect) or die ("DB���� ����");

session_start();
ini_set("session.use_trans_sid", 0);
ini_set("url_rewriter.tags","");
$id=$HTTP_SESSION_VARS['id'];

if ($_SERVER['PHP_SELF']=="/index.php") {
	if ($id) {
		echo '<script>location.replace("/main.php");</script>';
	}
	else { }
}
else {
	if ($id) { }
	else {
		if ($_SERVER['PHP_SELF']!="/login.php") {
			echo '<script>alert("�α��� ���ּ���!!"); location.replace("/index.php");</script>';
		}
	}
}
$sms="";
if ($_GET['sms']=="yes") {
	mysql_query ("UPDATE status SET check='0'", $connect);
	$agent_status=mysql_query ("SELECT * FROM status", $connect);
	while ($status=@mysql_fetch_array ($agent_status)) {
		$sms=$sms."agent".$status['id']."/".$status['alive']."|";
	}
}
$mem=@mysql_fetch_array (mysql_query ("SELECT * FROM member WHERE name='$id'", $connect));
?>
