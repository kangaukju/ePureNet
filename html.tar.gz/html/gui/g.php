<?php

include("./Includes/FusionCharts.php");
include("./queryFunction.php");
include("./gui.php");

?>
<HTML>
   <HEAD>
      <TITLE> IP Trace Statistics Chart </TITLE>
      <SCRIPT LANGUAGE="Javascript" SRC="FusionCharts.js"></SCRIPT>
      <style type="text/css">
			<!--
			body {
					font-family: Arial, Helvetica, sans-serif;
					font-size: 12px;
			}
			-->
	</style>
   </HEAD>
   <BODY>

   <?php
 // echo $query;
	
	

	$col1 = 0;
	while ($row = mysql_fetch_array($result)){
		if($row[0] ==" ")	$row[0]="none";
		$arrData[$col1][1] =  gethostbyaddr($row[0]);
		$arrData[$col1++][2] = $row[1];
//		echo $row[0];		
	}
//	echo $query;

	
   //Initialize <chart> element
   $strXML = "<chart caption='$title' numberPrefix='' formatNumberScale='0' rotateValues='1' placeValuesInside='1' decimals='0' >";

   //Initialize <categories> element - necessary to generate a multi-series chart
   $strCategories = "<categories>";


   $strDataCurr = "<dataset seriesName=''>";
   $strDataPrev = "<dataset seriesName=''>";

	//Now, we need to convert this data into XML. We convert using string concatenation.
	//Initialize <chart> element
	$strXML = "<chart caption='Sales by Product' numberPrefix='' formatNumberScale='0'>";
	//Convert data to XML and append
	foreach ($arrData as $arSubData)
		$strXML .= "<set label='" . $arSubData[1] . "' value='" . $arSubData[2] . "' />";

	//Close <chart> element
	$strXML .= "</chart>";
	
	//Create the chart - Column 3D Chart with data contained in strXML
	echo renderChart("./Bar2D.swf", "", $strXML, "productSales", 1000, 670, false, false);
?>
<a href='../body.php' >Prev</a>
</CENTER>
</BODY>
</HTML>
