

<?
/*
$table	:	DBname
$limit	:	count
$condition	:	s_ip, s_port, d_ip, d_port
$year	:	year
$mon	:	mon
$day	:	day
*/

function DB_query($table, $limit, $condition, $year, $mon, $day){
//	$condition = $_GET['condition'];
//	$year = $_POST['year'];
//	$mon = $_POST['mon'];
//	$day = $_POST['day'];     
	$query = "select $condition, count($condition) as count  from $table  group by 1 having date = '$year/$mon/$day' ORDER BY count desc  limit $limit";
	return $query;
}
function LIVE_simple_query($table, $limit, $condition, $year, $mon, $day){
	$wellknow_port = 1024;
	$query = "select *  from $table where  sport != ' ' and dport != ' '  and 	sip regexp !'^255' and sip regexp !'^0' and dip regexp !'^255' and dip regexp !'^0' and dport <= $wellknow_port";
}

function LIVE_detail_query($table, $limit, $condition, $year, $mon, $day){
	$wellknow_port = 1024;
	$query = "select *  from $table where  sport != ' ' and dport != ' '  and 	sip regexp !'^255' and sip regexp !'^0' and dip regexp !'^255' and dip regexp !'^0'";
}

?>