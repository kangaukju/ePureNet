<?php include "include/inc.php";

header('Content-Type: text/xml;charset=utf-8');

echo "<?xml version='1.0' encoding='utf-8' ?>";
echo "<root>";

$real_status=mysql_query ("SELECT * FROM status", $connect);
$i=0;
while ($real=@mysql_fetch_array ($real_status)) {
	if ($real['alive']==0 && $real['checks']!=1) {
		mysql_query ("UPDATE status SET checks='1' WHERE id='$real[id]'", $connect);
		echo "<sms agent='agent".$real['id']."'></sms>";
	}
	echo "<statuss agent='agent".$real['id']."' alive='".$real['alive']."'></statuss>";
	$i++;
}
echo "</root>";
?>