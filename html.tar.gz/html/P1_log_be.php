<?php include "header.php"; ?>
<table width="760px" border="0" cellpadding="0" cellspacing="0" class="bg_center">
<tr height="20px">
<td valign="top" class="paddingL10"><img src="img/log_come.gif" alt="���� �αװ�������" class="cursor" onclick="be_come('<?=$_GET['agent']?>', '<?=$mysql_server?>');" /></td>
</tr>
<tr>
<td valign="top">
	<form name="form" method="get" action="<?=$_SERVER['PHP_SELF']?>">
	<input type="hidden" name="agent" value="<?=$_GET['agent']?>">
	<table width="390px" border="0" cellpadding="5" cellspacing="0" class="C1_table">
	<tr>
	<td width="110px">��ȸ��¥</td>
	<td align="right">
		<select name="year" class="selectbox">
			<option value="">����</option>
			<?php for ($i=2007; $i<2020; $i++) { 
				if ($i==$_GET['year']) { ?>
					<option value=<?=$i?> selected><?=$i?></option>
				<?php } 
				else { ?>
					<option value=<?=$i?>><?=$i?></option>
				<?php }
			} ?>
		</select>
	</td>
	<td>��</td>
	<td align="right">
		<select name="mon" class="selectbox">
			<option value="">����</option>
			<?php for ($i=1; $i<13; $i++) { 
				if ($i==$_GET['mon']) { ?>
					<option value=<?=$i?> selected><?=$i?></option>
				<?php } 
				else { ?>
					<option value=<?=$i?>><?=$i?></option>
				<?php }
			} ?>
		</select>
	</td>
	<td>��</td>
	<td align="right">
		<select name="day" class="selectbox">
			<option value="">����</option>
			<?php $i=1;
			while ($i<=31) {
				if ($i==$_GET['day']) {
					echo '<option value='.$i.' selected>'.$i.'</option>';
				}
				else {
					echo '<option value='.$i.'>'.$i.'</option>';
				}
				$i++;
			} ?>
		</select>
	</td>
	<td>��</td>
	<td align="right">
		<select name="time" class="selectbox">
			<option value="">����</option>
			<?php $i=1;
			while ($i<=24) {
				if ($i==$_GET['time']) {
					echo '<option value='.$i.' selected>'.$i.'</option>';
				}
				else {
					echo '<option value='.$i.'>'.$i.'</option>';
				}
				$i++;
			} ?>
		</select>
	</td>
	<td>��</td>
	</tr>
	<tr>
	<td>����� IP</td>
	<td colspan="6"><input type="text" name="start_ip" class="search_input" value="<?=$_GET['start_ip']?>" /></td>
	<td rowspan="2" colspan="2"><input type="submit" value="�˻�" class="search_submit" />
	</tr>
	<tr>
	<td>������ IP</td>
	<td colspan="6" colspan="2"><input type="text" name="end_ip" class="search_input" value="<?=$_GET['end_ip']?>" /></td>
	</tr>
	</table>
	</form>
</td>
</tr>
<?php if ($_GET['agent']) { ?>
	<tr>
	<td valign="top">
		<table width="654px" border="0" cellpadding="5" cellspacing="0" class="CL_table">
		<tr height="40px" valign="top">
		<th>No.</th>
		<th>����� IP</th>
		<th>��Ʈ</th>
		<th>������ IP</th>
		<th>��Ʈ</th>
		<th>url</th>
		<th>��¥</th>
		<th>�ð�</th>
		</tr>
		<?php
		$database='review';

		$connect=mysql_connect ($mysql_server, $db_user, $db_password);
		mysql_select_db($database, $connect) or die ("DB���� ����");

		if ($_GET['day']=="1" || $_GET['day']=="2" || $_GET['day']=="3" || $_GET['day']=="4" || $_GET['day']=="5" || $_GET['day']=="6" || $_GET['day']=="7" || $_GET['day']=="8" || $_GET['day']=="9") {
			$table_day="0".$_GET['day'];
		}
		else {
			$table_day=$_GET['day'];
		}
		if ($_GET['time']=="1" || $_GET['time']=="2" || $_GET['time']=="3" || $_GET['time']=="4" || $_GET['time']=="5" || $_GET['time']=="6" || $_GET['time']=="7" || $_GET['time']=="8" || $_GET['time']=="9") {
			$table_time="0".$_GET['time'];
		}
		else {
			$table_time=$_GET['time'];
		}
		$table="AG".$table_day.$table_time;

		$query1="SELECT count(*) FROM $table";
		if ($_GET['start_ip']!="" && $_GET['end_ip']!="") {
			$query1="SELECT count(*) FROM $table WHERE src_ip='$_GET[start_ip]' AND dest_ip='$_GET[end_ip]'";
		}
		else if ($_GET['start_ip']=="" && $_GET['end_ip']!="") {
			$query1="SELECT count(*) FROM $table WHERE dest_ip='$_GET[end_ip]'";
		}
		else if ($_GET['start_ip']!="" && $_GET['end_ip']=="") {
			$query1="SELECT count(*) FROM $table WHERE src_ip='$_GET[start_ip]'";
		}
		$result1=mysql_query($query1, $connect);
		$total=@mysql_fetch_array($result1);
		$total=$total["count(*)"];
		$page=30;
		$pagesu=ceil($total/$page);
		$start=($page*$pagenum);
		$query2="SELECT * FROM $table LIMIT $start, $page";
		if ($_GET['start_ip']!="" && $_GET['end_ip']!="") {
			$query2="SELECT * FROM $table WHERE src_ip='$_GET[start_ip]' AND dest_ip='$_GET[end_ip]' LIMIT $start, $page";
		}
		else if ($_GET['start_ip']=="" && $_GET['end_ip']!="") {
			$query2="SELECT * FROM $table WHERE dest_ip='$_GET[end_ip]' LIMIT $start, $page";
		}
		else if ($_GET['start_ip']!="" && $_GET['end_ip']=="") {
			$query2="SELECT * FROM $table WHERE src_ip='$_GET[start_ip]' LIMIT $start, $page";
		}
		$result2=mysql_query($query2, $connect);
		$pageviewsu=10;
		$pagegroup=ceil(($pagenum+1)/$pageviewsu);
		$pagestart=($pageviewsu*($pagegroup-1))+1;
		$pageend=$pagestart+$pageviewsu-1;
		$totals=ceil($total/$page)-1;
		if ($_GET['pagenum']=="0" || !$_GET['pagenum']) { $k=$total+1; }
		else { $k=$total-($page*$pagenum)+1; }
		if ($total>0) {
			while ($agent_list=@mysql_fetch_array ($result2)) { ?>
				<tr align="center">
				<td class="borderB"><?=$k?></td>
				<td class="borderB"><?=$agent_list['src_ip']?></td>
				<td class="borderB"><?=$agent_list['src_port']?></td>
				<td class="borderB"><a href="http://<?=$agent_list['dest_ip']?>" target="_blank"><?=$agent_list['dest_ip']?></a></td>
				<td class="borderB"><?=$agent_list['dest_port']?></td>
				<td class="borderB"><?=$agent_list['url']?></td>
				<td class="borderB"><?=$agent_list['date']?></td>
				<td class="borderB"><?=$agent_list['time']?></td>
				</tr>
			<?php 
			$k--;
			} ?>
			<tr>
			<td colspan="8" height="50px" align="center" class="paging">
				<?php
				if ($pagenum) {
					$prevpage=$pagenum-1;
					if($prevpage<0) {
					}
					else {
						echo '<a href='.$_SERVER['PHP_SELF'].'?pagenum='.$prevpage.'&agent='.$_GET['agent'].'&year='.$_GET['year'].'&mon='.$_GET['mon'].'&day='.$_GET['day'].'&time='.$_GET['time'].'&start_ip='.$_GET['start_ip'].'&end_ip='.$_GET['end_ip'].'>����</a><span> | </span>';
					}
				}
				for ($i=$pagestart; $i<=$pageend; $i++) {
					$j=$i-1;
					if ($pagesu<$i) {
						break;
					}
					if ($j<0) {
					}
					else {
						if ($j==$pagenum) {
							if ($pagenum==0 || ($pagenum+1)==$pagestart) {
							}
							else {
								echo '<span> | </span>';
							}
							echo '<span style="color:#fb4622;"><strong>'.$i.'</strong></span>';
						}
						else {
							if ($i==1 || $i==$pagestart) {
							}
							else {
								echo '<span> | </span>';
							}
							echo '<a href='.$_SERVER['PHP_SELF'].'?pagenum='.$j.'&agent='.$_GET['agent'].'&year='.$_GET['year'].'&mon='.$_GET['mon'].'&day='.$_GET['day'].'&time='.$_GET['time'].'&start_ip='.$_GET['start_ip'].'&end_ip='.$_GET['end_ip'].'>'.$i.'</a>';
						}
					}
				}
				if (($pagenum+1)!=$pagesu) {
					$nextpage=$pagenum+1;
					if($pagenum+1>$totals) {
					}
					else {
						echo '<span> | </span><a href='.$_SERVER['PHP_SELF'].'?pagenum='.$nextpage.'&agent='.$_GET['agent'].'&year='.$_GET['year'].'&mon='.$_GET['mon'].'&day='.$_GET['day'].'&time='.$_GET['time'].'&start_ip='.$_GET['start_ip'].'&end_ip='.$_GET['end_ip'].'>����</a>';
					}
				}
				?>
			</td>
			</tr>
		<?php }
		else { ?>
			<tr>
			<td colspan="9" align="center">�˻��� ������ �����ϴ�.</td>
			</tr>
		<?php } ?>
		</table>
	</td>
	</tr>
<?php } ?>
</table>
<?php include "footer.php"; ?>
