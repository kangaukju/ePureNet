<?php include "include/incs.php";

if ($_POST['where']=="url") {
	$type="1";
}
else if ($_POST['where']=="keyword") {
	$type="2";
}
else if ($_POST['where']=="ip") {
	$type="2";
}
if ($_POST['category']) {
	$cate=$_POST['category'];
}
else {
	$cate=20;
}
mysql_query ("INSERT INTO $_POST[where] (type, catagory, content) VALUES ('$type', '$cate', '$_POST[address]')", $connect);
?>