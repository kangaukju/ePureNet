#!/bin/bash

/usr/local/pnrg/pnrg.pl --spool=/usr/local/pnrg/spool/
/usr/local/pnrg/pnrg-cgikeeper.pl --spool=/usr/local/pnrg/spool/
/usr/local/pnrg/pnrg-indexmaker.pl --spool=/usr/local/pnrg/spool/
