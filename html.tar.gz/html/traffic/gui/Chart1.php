<?php
//We've included ../Includes/FusionCharts_Gen.php, which contains FusionCharts PHP Class
//to help us easily embed the charts.
//include("./gui/FusionCharts_Gen.php");
?>
<HTML>
<HEAD>
	<TITLE>

	</TITLE>
	<?php
	//You need to include the following JS file, if you intend to embed the chart using JavaScript.
	//Embedding using JavaScripts avoids the "Click to Activate..." issue in Internet Explorer
	//When you make your own charts, make sure that the path to this JS file is correct. Else, you would get JavaScript errors.
	?>	
	<SCRIPT LANGUAGE="Javascript" SRC="./gui/FusionCharts.js"></SCRIPT>
	<style type="text/css">
	<!--
	body {
		font-family: Arial, Helvetica, sans-serif;
		font-size: 14px;
	}
	-->
	</style>
</HEAD>
<BODY>

<CENTER>

<?php


	$i = 0;
	$arrData1[0][0] = "";
	$arrData1[0][1] = "showValues=0;"; // Dataset Parameters
	$arrData1[1][0] = "";
	$arrData1[1][1] = "parentYAxis=S"; // Dataset Parameters
	
	while ($row = mysql_fetch_array($result)){
	$day = substr($row[0] , 8, 2);
	$arrDataCat1[$i] = $day."��";
	echo $day."<br>";

	
	echo $row[1]."<br>";
	$arrData1[0][$i+2] = $row[1];	
	$date = $row[1];
	$arrData1[1][$i+2] = $date;
	$i++;		
	}
	$arrData = $arrData1;
	
	# Create combination chart object
 	$FC = new FusionCharts("MSColumn3DLineDY","1000","500"); 

	# Set Relative Path of swf file. 
 	$FC->setSwfPath("./gui/Charts/");
	
	#Store the chart attributes in a variable
	$strParam="caption=�ð� ���� Traffic;PYAxisName=traffic bytes;decimalPrecision=2;anchorSides=10; anchorRadius=3";

 	# Set chart attributes
 	$FC->setChartParams($strParam);
	
	
	# Pass the 2 arrays storing data and category names to 
	# FusionCharts PHP Class function addChartDataFromArray
	$FC->addChartDataFromArray($arrData, $arrDataCat);	

	# Render the chart
 	$FC->renderChart();
	
?>
<BR><BR>

</CENTER>
</BODY>
</HTML>