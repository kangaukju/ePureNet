<?php include "include/inc.php";

$table=$_POST['agent'][5];
$value=@mysql_fetch_array (mysql_query ("SELECT * FROM status WHERE id='$table'", $connect));
echo $value['cpu']."/".$value['mem']."/".$value['disk1']."/".$value['disk2'];
?>