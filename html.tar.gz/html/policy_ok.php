<?php
if( $_POST['agent'] ){	
	$value=explode("agent", $_POST['agent']);
	$LIVE_REQ = "POLY".$value[1];
	$recv_data;
	$dest= $_POST['ip'];
	$port = $_POST['port'];
	$port = 9000;

	$interval = 300;
	$start_time;
	$end_time;



  if(false === $socket = @socket_create(AF_INET, SOCK_STREAM, 0)){
		echo "socket create error<br>";	// !!!!!!!!����!!!!!!!!!!!!!!
	}
	else{		
		if(false === @socket_connect($socket, $dest, $port)){
			echo "socket_connect error<br>";	// !!!!!!!!����!!!!!!!!!!!!!!
		}
		else{			
			if(false === @socket_write ($socket, $LIVE_REQ, strlen($LIVE_REQ))){
				echo "socket_write error<br>";	// !!!!!!!!����!!!!!!!!!!!!!!
			}
			else{
				//$start_time = date('is');
				//$end_time = date('is',time()+$interval);
				$end_time = time()+$interval;
				
				socket_set_nonblock($socket);
				
				while(true)
				{
					if($recv_data = socket_read ($socket, 10) ){
						echo "Y";	// !!!!!!!!����!!!!!!!!!!!!!!
						break;
					}
					else if(time() > $end_time){
						echo "N";
						break;				// !!!!!!!!����!!!!!!!!!!!!!!
					}
					sleep(1);
				}	
			}
		}
	}
}
else{

	echo "N";

}
?>
