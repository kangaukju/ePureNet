<?php include "include/incs.php";

$table=$_POST['agent']."_netobj";
mysql_query ("INSERT INTO $table (netobj) VALUES ('$_POST[netobj]')", $connect);
?>