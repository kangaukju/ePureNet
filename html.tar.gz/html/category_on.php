<?php include "include/incs.php";

$table=$_POST['agent']."_policy";
mysql_query ("DELETE FROM $table WHERE catagory='$_POST[value]' AND type='1' AND netobj='$_POST[netobj]'", $connect);
mysql_query ("DELETE FROM $table WHERE netobj='$_POST[netobj]' AND catagory='$_POST[value]' AND type='2'", $connect);
mysql_query ("DELETE FROM $table WHERE netobj='$_POST[netobj]' AND catagory='$_POST[value]' AND type='3'", $connect);

?>