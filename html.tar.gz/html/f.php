<HTML>
<BODY bgcolor="#FFFFFF">

<?php
include "charts.php";

//insert 3 different charts into the web page with 3 different chart sources
echo InsertChart ( "charts.swf", "charts_library", "sample_1.php" );
echo InsertChart ( "charts.swf", "charts_library", "sample_2.php" );
echo InsertChart ( "charts.swf", "charts_library", "sample_3.php" );

?>

</BODY>
</HTML>


