<?php include "header.php";
include "./Includes/FusionCharts.php";
include "./queryFunction.php";
?>
<table width="760px" border="0" cellpadding="0" cellspacing="0" class="bg_center">
<tr height="90px">
<td valign="top">
	<form method="post" action="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>">
	<input type="hidden" name="agent" value="<?=$_GET['agent']?>">
	<table width="350px" border="0" cellpadding="5" cellspacing="0" class="C1_table">
	<tr>
	<td width="90px">��ȸ��¥</td>
	<td align="right">
		<select name="year" class="selectbox">
			<?php $year=date("Y", time()); ?>
			<option value=<?=$year?>><?=$year?></option>
		</select>
	</td>
	<td>��</td>
	<td align="right">
		<select name="mon" class="selectbox">
			<?php $month=date("m", time()); 
			if ($month=="01") {
				$mon=1;
			}
			else if ($month=="02") {
				$mon=2;
			} 
			else if ($month=="03") {
				$mon=3;
			} 
			else if ($month=="04") {
				$mon=4;
			} 
			else if ($month=="05") {
				$mon=5;
			} 
			else if ($month=="06") {
				$mon=6;
			} 
			else if ($month=="07") {
				$mon=7;
			} 
			else if ($month=="08") {
				$mon=8;
			} 
			else if ($month=="09") {
				$mon=9;
			}
			else {
				$mon=$month;
			} ?>
			<option value=<?=$mon?>><?=$mon?></option>
		</select>
	</td>
	<td>��</td>
	<td align="right">
		<select name="day" class="selectbox">
		<?php $i=1;
		while ($i<=31) {
			if ($i==$_POST['day']) {
				echo '<option value='.$i.' selected>'.$i.'</option>';
			}
			else {
				echo '<option value='.$i.'>'.$i.'</option>';
			}
			$i++;
		} ?>
		</select>
	</td>
	<td>��</td>
	<td><input type="submit" value="�˻�" class="search_submit" /></td>
	</tr>
	</table>
	</form>

	<?php
	if ($_POST['year']) { ?>
		<table width="100%" border="0" cellpadding="0" cellspacing="0" class="paddingL10T20">
		<tr>
		<td>
			<?php
			$year=$_POST['year'];
			$mon=$_POST['mon'];
			$day=$_POST['day'];
			$hour=$_POST['hour'];
			$agent=$_POST['agent'];

			$connect=mysql_connect($mysql_server,$db_user,$db_password) or die("");
			$date=$year."-".$mon."-".$day;	
			$query="select tbyte, gbyte, mbyte, kbyte, byte, time from statics.".$agent. " where date='".$date."'";
			$result=mysql_query($query);
			$col1=0;
			
			while ($row=@mysql_fetch_array($result)){			
//				$size=$row[4] + $row[3]*1024 + $row[2]*1024*1024 + $row[1]*1024*1024*1024 + $row[0]*1024*1024*1024*1024;
				$size=$row[3]*0.1 + $row[2] + $row[1]*1024 + $row[0]*1024*1024;
/*
				if($size >= 1024*1024*1024*1024)
								$size = $size."TB";
				else if($size >= 1024*1024*1024)
								$size = $size."GB";
				else if($size >= 1024*1024)
								$size = $size."MB";
				else if($size >= 1024)
                $size = $size."KB";
				else
								$size = $size."Byte";
	*/							
				$next_hour=$row['5']+1;
				$arrData[$col1][1]=$row['5']."~".$next_hour." hour";
				$arrData[$col1++][2]=$size;
			}
			
			$strXML="<chart caption='$title' numberPrefix='' formatNumberScale='0' rotateValues='1' placeValuesInside='1' decimals='0' >";
			$strCategories="<categories>";
			$strDataCurr="<dataset seriesName=''>";
			$strDataPrev="<dataset seriesName=''>";
			$strXML="<chart caption='A mount of Traffic at This DAY(MBytes)' numberPrefix='' formatNumberScale='0'>";
			foreach ($arrData as $arSubData)
			$strXML.="<set label='" . $arSubData[1] . "' value='" . $arSubData[2] . "' />";
			$strXML.="</chart>";
			echo renderChart("./Bar2D.swf", "", $strXML, "productSales", 760, 670, false, false);
			?>
		</td>
		</tr>
		</table>
	<?php } ?>
</td>
</tr>
</table>
<?php include "footer.php"; ?>
