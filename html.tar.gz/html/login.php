<?php include "include/inc.php";

$password=md5($_POST['pass']);
$check=@mysql_fetch_array (mysql_query ("SELECT * FROM member WHERE ip='$_POST[ip]' AND name='$_POST[id]' AND pass='$password'", $connect));

if ($check) {
	session_register("id");
	$id=$_POST['id'];
	echo "Y";
}
else {
	echo "N";
}

?>