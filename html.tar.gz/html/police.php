<?php include "header.php"; 
$database="policy";

$connect=mysql_connect ($mysql_server, $db_user, $db_password);
mysql_select_db($database, $connect) or die ("DB���� ����");
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" class="paddingT10L10">
<tr>
<td>
	<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
	<td width="270px">
		<table border="0" cellpadding="0" cellspacing="0" class="P_box">
		<tr>
		<td>+ ��Ʈ��ũ ��ü</td>
		</tr>
		<tr>
		<td>
			<div class="D_box">
				<?php
				$table1=$_GET['agent']."_netobj";
				$netobj_list=mysql_query ("SELECT * FROM $table1", $connect);
				?>
				<input type="button" value="�߰�" onclick="window.open ('netobj_add.php?agent=<?=$_GET['agent']?>', 'new', 'width=200, height=100, scrollbars=no');" /><br />
				<?php $i=1;
				while ($netobj=@mysql_fetch_array ($netobj_list)) { 
					if ($_GET['netobj']==$netobj['netobj']) { ?>
						<input type="hidden" id="R_netobj_<?=$i?>" value="<?=$netobj['netobj']?>" />
						<input type="text" id="netobj_<?=$i?>" value="<?=$netobj['netobj']?>" style="background-color:#000; color:#fff; border:0;" onclick="location.replace('<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj='+this.value+'&where=url');" />
						<input type="button" value="����" onclick="netobj_modify('<?=$_GET['agent']?>', '<?=$i?>');" />
						<input type="button" value="����" onclick="netobj_del('<?=$_GET['agent']?>', '<?=$i?>');" />
					<?php }
					else { ?>
						<input type="hidden" id="R_netobj_<?=$i?>" value="<?=$netobj['netobj']?>" />
						<input type="text" id="netobj_<?=$i?>" value="<?=$netobj['netobj']?>" onclick="location.replace('<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj='+this.value+'&where=url');" style="border:0;" />
						<input type="button" value="����" onclick="netobj_modify('<?=$_GET['agent']?>', '<?=$i?>');" />
						<input type="button" value="����" onclick="netobj_del('<?=$_GET['agent']?>', '<?=$i?>');" />
					<?php }
					$i++;
				} ?>
			</div>
		</td>
		</tr>
		</table>
	</td>
	<td align="left">
		<table border="0" cellpadding="0" cellspacing="0" class="P_box">
		<tr>
		<td>+ ȣ��Ʈ �׷�</td>
		</tr>
		<tr>
		<td>
			<div class="D_box">
				<?php
				$table2=$_GET['agent']."_group";
				if ($_GET['netobj']) {
					$host_list=mysql_query ("SELECT * FROM $table2 WHERE netobj='$_GET[netobj]'", $connect);
				}
				else {
					$host_list=mysql_query ("SELECT * FROM $table2", $connect);
				}
				?>
				<input type="button" value="�߰�" onclick="window.open ('host_add.php?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>', 'new', 'width=200, height=200, scrollbars=no');" /><br />
				<?php $i=1;
				while ($host=@mysql_fetch_array ($host_list)) { ?>
						<input type="hidden" id="R_host_<?=$i?>" value="<?=$host['host']?>" />
						<input type="text" id="host_<?=$i?>" value="<?=$host['host']?>" style="border:0;" />
						<input type="button" value="����" onclick="host_modify('<?=$_GET['agent']?>', '<?=$i?>');" />
						<input type="button" value="����" onclick="host_del('<?=$_GET['agent']?>', '<?=$i?>');" />
					<?php $i++;
				} ?>
			</div>
		</td>
		</tr>
		</table>
	</td>
	</tr>
	</table>
</td>
</tr>
<tr>
<td class="paddingT10">
	<table width="100%" border="0" cellpadding="0" cellspacing="0" class="U_list">
	<tr>
	<td><strong>=> <?=$_GET['netobj']?></strong></td>
	</tr>
	<tr>
	<td class="paddingT10">
		<table border="0" cellpadding="0" cellspacing="0" class="Border">
		<tr>
		<td width="150px" valign="top" class="url_R">
			<table width="100%" border="0" cellpadding="2" cellspacing="0" class="P_btns">
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate="><img src="img/btn_cateall.gif" alt="����" /></a></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=1"><img src="img/btn_cate1.gif" alt="����" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '1', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '1', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=2"><img src="img/btn_cate2.gif" alt="����" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '2', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '2', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=3"><img src="img/btn_cate3.gif" alt="����" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '3', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '3', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=4"><img src="img/btn_cate4.gif" alt="��ȸ" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '4', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '4', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=5"><img src="img/btn_cate5.gif" alt="��ǻ��" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '5', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '5', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=6"><img src="img/btn_cate6.gif" alt="����" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '6', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '6', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=7"><img src="img/btn_cate7.gif" alt="�̵��" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '7', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '7', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=8"><img src="img/btn_cate8.gif" alt="��Ȱ/�ǰ�" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '8', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '8', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=9"><img src="img/btn_cate9.gif" alt="��ȭ" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '9', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '9', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=10"><img src="img/btn_cate10.gif" alt="����" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '10', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '10', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=11"><img src="img/btn_cate11.gif" alt="����" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '11', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '11', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=12"><img src="img/btn_cate12.gif" alt="����" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '12', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '12', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=13"><img src="img/btn_cate13.gif" alt="������" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '13', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '13', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=14"><img src="img/btn_cate14.gif" alt="����" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '14', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '14', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=15"><img src="img/btn_cate15.gif" alt="p2p" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '15', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '15', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=16"><img src="img/btn_cate16.gif" alt="���/����" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '16', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '16', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=17"><img src="img/btn_cate17.gif" alt="���ͳ�" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '17', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '17', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=18"><img src="img/btn_cate18.gif" alt="����" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '18', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '18', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=19"><img src="img/btn_cate19.gif" alt="��ġ" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '19', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '19', '<?=$_GET['where']?>');" /></td>
			</tr>
			<tr>
			<td><a href="<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where=<?=$_GET['where']?>&word=<?=$_GET['word']?>&cate=20"><img src="img/btn_cate20.gif" alt="��Ÿ" /></a><input type="button" value="����" title="��ü����"  onclick="category_on('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '20', '<?=$_GET['where']?>');" /><input type="button" value="����" title="��ü���� ����"  onclick="category_off('<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '20', '<?=$_GET['where']?>');" /></td>
			</tr>
			</table>
		</td>
		<td valign="top" class="paddingL10R10">
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
			<tr>
			<td class="paddingT10">
				<form method="get" action="<?=$_SERVER['PHP_SELF']?>">
				<input type="hidden" name="agent" value="<?=$_GET['agent']?>" />
				<input type="hidden" name="netobj" value="<?=$_GET['netobj']?>" />
				<select name="where" class="selectbox" onchange="location.replace('<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&netobj=<?=$_GET['netobj']?>&where='+this.value);">
					<option value="">����</option>
					<?php if ($_GET['where']=="url") { ?>
						<option value="url" selected>URL</option>
					<?php }
					else { ?>
						<option value="url">URL</option>
					<?php } ?>
					<?php if ($_GET['where']=="keyword") { ?>
						<option value="keyword" selected>KEYWORD</option>
					<?php }
					else { ?>
						<option value="keyword">KEYWORD</option>
					<?php } ?>
					<?php if ($_GET['where']=="ip") { ?>
						<option value="ip" selected>IP</option>
					<?php }
					else { ?>
						<option value="ip">IP</option>
					<?php } ?>
				</select>
				<input type="text" name="word" value="<?=$_GET['word']?>" style="width:300px;" />
				<input type="submit" value="�˻�" />
				</form>
			</td>
			</tr>
			<tr>
			<td class="paddingT10">
				<table width="620px" border="0" cellpadding="2" cellspacing="0" class="UR_list">
				<tr>
				<th>url</th>
				<th width="25px">����</th>
				<th>url</th>
				<th width="25px">����</th>
				<th>url</th>
				<th width="25px">����</th>
				</tr>
				<tr>
				<?php
				$query1="SELECT count(*) FROM $_GET[where]";
				if ($_GET['word']!="") {
					$query1="SELECT count(*) FROM $_GET[where] WHERE content LIKE '%$_GET[word]%'";
				}
				if ($_GET['cate']!="") {
					$query1="SELECT count(*) FROM $_GET[where] WHERE catagory='$_GET[cate]' AND content LIKE '%$_GET[word]%'";
				}
				$result1=mysql_query($query1, $connect);
				$total=@mysql_fetch_array($result1);
				$total=$total["count(*)"];
				$page=90;
				$pagesu=ceil($total/$page);
				$start=($page*$pagenum);
				$query2="SELECT * FROM $_GET[where] LIMIT $start, $page";
				if ($_GET['word']!="") {
					$query2="SELECT * FROM $_GET[where] WHERE content LIKE '%$_GET[word]%' LIMIT $start, $page";
				}
				if ($_GET['cate']!="") {
					$query2="SELECT * FROM $_GET[where] WHERE catagory='$_GET[cate]' AND content LIKE '%$_GET[word]%' LIMIT $start, $page";
				}
				$result2=mysql_query($query2, $connect);
				$pageviewsu=10;
				$pagegroup=ceil(($pagenum+1)/$pageviewsu);
				$pagestart=($pageviewsu*($pagegroup-1))+1;
				$pageend=$pagestart+$pageviewsu-1;
				$totals=ceil($total/$page)-1;
				if ($_GET['pagenum']=="0" || !$_GET['pagenum']) { $k=$total+1; }
				else { $k=$total-($page*$pagenum)+1; }
				if ($total>0) {
					$i=1;
					while ($url=@mysql_fetch_array ($result2)) { ?>
						<td><?=$url['content']?></td>
						<td align="center">
						<?php
						$url_table=$_GET['agent']."_policy";
						$check=@mysql_fetch_array (mysql_query ("SELECT * FROM $url_table WHERE netobj='$_GET[netobj]' AND no='$url[no]' AND type='$url[type]'", $connect));
						if ($check) { ?>
							<input type="checkbox" value="<?=$url['content']?>" checked onclick="url_check(this, this.value, '<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '<?=$_GET['where']?>', '<?=$url['no']?>');">
						<?php }
						else { ?>
							<input type="checkbox" value="<?=$url['content']?>" onclick="url_check(this, this.value, '<?=$_GET['agent']?>', '<?=$_GET['netobj']?>', '<?=$_GET['where']?>', '<?=$url['no']?>');">
						<?php } ?>
						</td>
						<?php
							if ($i%3==0) { ?>
							</tr>
							<tr>
						<?php }
					$i++;
					} ?>
					</tr>
					<tr>
					<td height="30px" colspan="6" class="paging" align="center">
						<?php
						if ($pagenum) {
							$prevpage=$pagenum-1;
							if($prevpage<0) {
							}
							else {
								echo '<a href='.$_SERVER['PHP_SELF'].'?pagenum='.$prevpage.'&agent='.$_GET['agent'].'&netobj='.$_GET['netobj'].'&where='.$_GET['where'].'&word='.$_GET['word'].'&cate='.$_GET['cate'].'>����</a><span> | </span>';
							}
						}
						for ($i=$pagestart; $i<=$pageend; $i++) {
							$j=$i-1;
							if ($pagesu<$i) {
								break;
							}
							if ($j<0) {
							}
							else {
								if ($j==$pagenum) {
									if ($pagenum==0 || ($pagenum+1)==$pagestart) {
									}
									else {
										echo '<span> | </span>';
									}
									echo '<span style="color:#fb4622;"><strong>'.$i.'</strong></span>';
								}
								else {
									if ($i==1 || $i==$pagestart) {
									}
									else {
										echo '<span> | </span>';
									}
									echo '<a href='.$_SERVER['PHP_SELF'].'?pagenum='.$j.'&agent='.$_GET['agent'].'&netobj='.$_GET['netobj'].'&where='.$_GET['where'].'&word='.$_GET['word'].'&cate='.$_GET['cate'].'>'.$i.'</a>';
								}
							}
						}
						if (($pagenum+1)!=$pagesu) {
							$nextpage=$pagenum+1;
							if($pagenum+1>$totals) {
							}
							else {
								echo '<span> | </span><a href='.$_SERVER['PHP_SELF'].'?pagenum='.$nextpage.'&agent='.$_GET['agent'].'&netobj='.$_GET['netobj'].'&where='.$_GET['where'].'&word='.$_GET['word'].'&cate='.$_GET['cate'].'>����</a>';
							}
						}
						?>
					</td>
				<?php }
				else { ?>
					<td align="center" colspan="6">����� �����ϴ�.</td>
				<?php } ?>
				</tr>
				</table>
			</td>
			</tr>
			<tr>
			<td align="right">
				<table border="0" cellpadding="5" cellspacing="0">
				<tr>
				<td align="right"><input type="button" value="�߰�" onclick="window.open ('address_add.php?agent=<?=$_GET['agent']?>', 'new', 'width=330, height=200, scrollbars=no');" style="margin-top:2px;"/></td>
				<td><img src="img/btn_agree.gif" alt="��å����" style="border:1px solid #4e4e4e; cursor:pointer;" onclick="agree('<?=$mysql_server?>', '<?=$_GET['agent']?>', '<?=$_GET['netobj']?>');" /></td>
				</tr>
				</table>
			</td>
			</tr>
			</table>
		</td>
		</tr>
		</table>
	</td>
	</tr>
	</table>
</td>
</tr>
</table>
<?php include "footer.php"; ?>
