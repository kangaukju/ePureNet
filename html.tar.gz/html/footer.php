		</td>
		</tr>
		</table>
	</td>
	</tr>
	</table>
</td>
</tr>
<tr>
<td align="center"><img src="img/copyright.gif" alt="copyright" /></td>
</tr>
</table>
</body>
</html>