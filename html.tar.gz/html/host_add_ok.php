<?php include "include/incs.php";

$table=$_POST['agent']."_group";
mysql_query ("INSERT INTO $table (netobj, host) VALUES ('$_POST[netobj]', '$_POST[host]')", $connect);
?>