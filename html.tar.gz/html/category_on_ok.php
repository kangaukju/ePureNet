<?php include "include/incs.php";

$table=$_POST['agent']."_policy";

if ($_POST['where']=="url") {
	$url_list=mysql_query ("SELECT * FROM url WHERE catagory='$_POST[value]'", $connect);
	while ($url=@mysql_fetch_array ($url_list)) {
		mysql_query ("INSERT INTO $table (netobj, type, catagory, no) VALUES ('$_POST[netobj]', '1', '$_POST[value]', '$url[no]')", $connect);
	}
}

if ($_POST['where']=="keyword") {
	$keyword_list=mysql_query ("SELECT * FROM keyword WHERE catagory='$_POST[value]'", $connect);
	while ($keyword=@mysql_fetch_array ($keyword_list)) {
		mysql_query ("INSERT INTO $table (netobj, type, catagory, no) VALUES ('$_POST[netobj]', '2', '$_POST[value]', '$keyword[no]')", $connect);
	}
}

if ($_POST['where']=="ip") {
	$ip_list=mysql_query ("SELECT * FROM ip WHERE catagory='$_POST[value]'", $connect);
	while ($ip=@mysql_fetch_array ($ip_list)) {
		mysql_query ("INSERT INTO $table (netobj, type, catagory, no) VALUES ('$_POST[netobj]', '3', '$_POST[value]', '$ip[no]')", $connect);
	}
}

?>