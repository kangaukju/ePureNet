
<style type="text/css">
			<!--
			td {
					font-family: Arial, Helvetica, sans-serif;
					font-size: 12px;
					text-align:center;
		
			}
			.user {
					font-family: Arial, Helvetica, sans-serif;
					font-size: 12px;
					color:red;
			}
			.search{
					background-color:;
				
			}
			 A:hover {text-decoration: none; color:orange} 
			 A:visited{text-decoration:none;}
			 A:link{text-decoration: none; color:black;}
			 .table {
	width: 100%;
	border: 1px solid #CCCFD3;
	background-color: #FFFFFF;
	padding: 1px;
}
			 

} 

			-->
</style>


<?
function conv_time($m){
	$str;
	for($i =1; $i<=24; $i++){
		if($i == $m){
			if($i < 10)	$i = "0".$i;				
			$str = "$i:00:00";
			return $str;
		}		
	}	
	
}

function conv_byte($m){
	$result;
	if($m >= 1024 * 1024 * 1024 * 1024){
		$su = round($m/(1024 * 1024 * 1024 * 1024), 2);
		$result = $su."T";
	}
	else if($m >= 1024 * 1024 * 1024){
		$su = round($m/(1024 * 1024 * 1024), 2);
		$result = $su."G";
	}
	else if($m >= 1024 * 1024){
		$su = round($m/(1024 * 1024), 2);
		$result = $su."M";
	}
	else if($m >= 1024){
		$su =round($m/(1024), 2);
		$result = $su."K";
	}
	else
		$result = $m."B";
	return $result;	
}

include "./../secure.inc";


$count_record = 0;
$total_record = 0;
$link_per 		= 10;
$page_per 		= 42;
$num 					= 0;
$printf_loop	=	0;
$exp;
$img_page =0;


if(!$_GET['block'])			$block 	= 0;
else						$block	=	$_GET['block'];

if(!$_GET['page'])			$page 	= 0;
else						$page	=	$_GET['page'];



if($_POST['year'])				$year		=	$_POST['year'];
else							$year		=	date("Y");

if($_POST['mon'])				$mon		=	$_POST['mon'];
else							$mon		=	date("m");

if($_POST['day'])				$day		=	$_POST['day'];
else							$day		=	date("d");

if($_POST['time'])				$time		=	$_POST['time'];

if($_POST['sel'])				$sel		=	$_POST['sel'];


if($_GET['year'])				$year		=	$_GET['year'];
if($_GET['mon'])				$mon		=	$_GET['mon'];
if($_GET['day'])				$day		=	$_GET['day'];

//echo "$year:$mon:$day<br>";

if($_POST['search']){
	$block 	= 0;
	$page		=	0;	
	$sip		=	$_POST['sip'];
	$dip		=	$_POST['dip'];
	$req		=	"yes";	
	$year		=	$_POST['year'];
	$mon		=	$_POST['mon'];
	$day		=	$_POST['day'];
	$img_page = 0;
	
}else{
	$img_page = 1;
	
}
?>

<?





echo conv_byte(1971);
?>
<form method="POST" action="" name=packet>

<table width= 950 border=0 align=center cellspacing=0 cellpadding=0 >	
<tr><td>
<table border=1 align=left cellspacing=0 cellpadding=0>	
	<tr>		
		<td >��ȸ ��¥</td>
		<td colspan=2>
			<select name=year>
<?
			for($q=2008; $q<=2012 ; $q++){
					if($year == $q)
						echo "<option value=$q selected>$q";
					else
						echo "<option value=$q >$q";
			}
?>
			</select>��&nbsp;&nbsp;&nbsp;&nbsp;
			<select name=mon>
<?
			for($q=1; $q<= 12; $q++){
					if($q < 10)		$q ="0".$q;
					if($mon == $q)
						echo "<option value=$q selected>$q";
					else
						echo "<option value=$q >$q";
			}
?>				
			</select>��&nbsp;&nbsp;&nbsp;&nbsp;
			<select name=day>
				<option value=0>��ü
<?
			for($q=1; $q<= 31; $q++){				
					if($q < 10)		$q ="0".$q;
					if($day == $q)
						echo "<option value=$q selected>$q";
					else
						echo "<option value=$q >$q";
			}
?>				
			</select>��
			<select name=time>
					<option value=0 >00:00 ~ 24:00</oprtion>
					<? 
					for($q=1; $q<= 23; $q++){						
						$n = $q+1;
						if($q < 10)		$q ="0".$q;
						if($n < 10)		$n ="0".$n;			
						echo ("<option value=$q >$q:00 ~ $n:00</oprtion>");
					}
					?>					
			</select>
		</td>
		
	</td></tr>	
</table>
</tr>
<tr><td>
<table border=1 align=left cellspacing=0 cellpadding=0>	
<tr>
	<td>�˻� ����
	</td>
	<td>
		<input type=radio name=sel value="sip">����� IP</input>
		<input type=radio name=sel value="sport">����� PORT</input>
		<input type=radio name=sel checked value="dip">������ IP</input>
		<input type=radio name=sel value="dport">������ PORT</input>
	</td>
	<td width=50>
	</td>
	<td><input type=submit value="ã��" name=search></input>
	</td>
</table>
</td></tr>

<tr><td>


<?
/****************************************** search ��ư�� ������ ��쿡�� ��踦 ������
********************************************/

	if($img_page == 0){
		for($i=0; $i<23; $i++){
		$from_time = conv_time($i);
		$to_time = conv_time($i+1);
	
		if($time == $i){
			if($time == 0){
				$time_str = ""; 
				break;
			}
			else{		
				$time_str = " and time >= '$from_time' and time < '$to_time' ";
				break;
			}		
		}	
	}
	echo "$time_str<br>";
	echo "$time";
	
?>
	<table border=1>
	<tr bgcolor=lightblue>		
	<?
	if($sel == 'sip'){
		$query 	= "select distinct(s_ip), sum(size), date, time  from cap_packet group by 1 having  date = '$year/$mon/$day' ".$time_str;
		
	?>
		<td width=10 bgcolor="lightyellow" align=center>No.</td>
		<td width=90 align=center>����� IP</td>
		<td width=60 align=center bgcolor=#FFCC99>Ʈ����</td> 
		<td width=130 align=center>��¥</td> 
		<td width=10 bgcolor="lightyellow" align=center>No.</td>
		<td width=90 align=center>����� IP</td>
		<td width=60 align=center bgcolor=#FFCC99>Ʈ����</td> 
		<td width=130 align=center>��¥</td> 
		<td width=10 bgcolor="lightyellow" align=center>No.</td>
		<td width=90 align=center>����� IP</td>
		<td width=130 align=center bgcolor=#FFCC99>Ʈ����</td> 
		<td width=60 align=center>��¥</td> 
	<?
	}else if($sel == 'sport'){
		$query 	= "select distinct(s_port), sum(size), date, time  from cap_packet group by 1 having  date = '$year/$mon/$day' ".$time_str;
	?>
		<td width=10 bgcolor="lightyellow" align=center>No.</td>
		<td width=90 align=center>����� ��Ʈ</td>
		<td width=60 align=center>Ʈ����(bytes)</td> 
		<td width=130 align=center>��¥</td> 
		<td width=10 bgcolor="lightyellow" align=center>No.</td>
		<td width=90 align=center>����� ��Ʈ</td>
		<td width=60 align=center>Ʈ����(bytes)</td> 
		<td width=130 align=center>��¥</td> 
		<td width=10 bgcolor="lightyellow" align=center>No.</td>
		<td width=90 align=center>����� ��Ʈ</td>
		<td width=60 align=center>Ʈ����(bytes)</td> 
		<td width=130 align=center>��¥</td> 
	<?
	}else if($sel == 'dip'){
		$query 	= "select distinct(d_ip), sum(size), date, time  from cap_packet group by 1 having  date = '$year/$mon/$day' ".$time_str;
	?>
		<td width=10 bgcolor="lightyellow" align=center>No.</td>
		<td width=90 align=center>������ IP</td>
		<td width=60 align=center>Ʈ����(bytes)</td> 
		<td width=130 align=center>��¥</td> 
		<td width=10 bgcolor="lightyellow" align=center>No.</td>
		<td width=60 align=center>������ IP</td>
		<td width=60 align=center>Ʈ����(bytes)</td> 
		<td width=130 align=center>��¥</td> 
		<td width=10 bgcolor="lightyellow" align=center>No.</td>
		<td width=90 align=center>������ IP</td>
		<td width=60 align=center>Ʈ����(bytes)</td> 
		<td width=130 align=center>��¥</td> 
	<?
	}else if($sel == 'dport'){
		$query 	= "select distinct(d_port), sum(size), date, time  from cap_packet group by 1 having  date = '$year/$mon/$day' ".$time_str;
	?>
		<td width=10 bgcolor="lightyellow" align=center>No.</td>
		<td width=90 align=center>������ ��Ʈ</td>
		<td width=60 align=center>Ʈ����(bytes)</td> 
		<td width=130 align=center>��¥</td> 
		<td width=10 bgcolor="lightyellow" align=center>No.</td>
		<td width=90 align=center>������ ��Ʈ</td>
		<td width=60 align=center>Ʈ����(bytes)</td> 
		<td width=130 align=center>��¥</td> 
		<td width=10 bgcolor="lightyellow" align=center>No.</td>
		<td width=90 align=center>������ ��Ʈ</td>
		<td width=60 align=center>Ʈ����(bytes)</td> 
		<td width=130 align=center>��¥</td> 
</td> 
</tr>
<br>
<?
}
	echo $query;
	$connect = mysql_connect($host,$user,$password) or die("");
	mysql_select_db($db) or die("");

	

//	$total_record = $row[0];


//$date = "$year/$mon/$day";
	

	$start_record = ($page_per-1) * $page + $block * $page_per * $link_per ;
	$num = ($start_record-1);
//echo $num."<br>";
//echo "block:". $block. "/".floor($total_record / ($page_per))."<br>";
//echo "��� ����  ��Ŷ ���ڵ� ��ȣ:".$start_record."<br>";



	$result = mysql_query($query);	
	$num = $start_record-1;	
	
	while ($row = mysql_fetch_array($result)){		
		$num++;
		echo ("	<tr height=\"20\" onMouseOver=\"this.style.backgroundColor='#ddeecc'\" onMouseOut=\"this.style.backgroundColor='white'\">
				<td bgcolor='lightyellow'>$num</td>
			");
		if($sel == 'dip' || $sel == 'sip')
		echo (" <td><a href='http://$row[0]'>$row[0]</a></td> ");
		else
		echo ("	<td>$row[0]</td>");
		$traffic = conv_byte($row[1]);
		echo ("	<td>$row[1]<br>($traffic)</td>
				<td>$row[2]</td>
			");
		$row = mysql_fetch_array($result);
		$num++;
		echo ("	<td bgcolor='lightyellow'>$num</td>
			");
		if($sel == 'dip' || $sel == 'sip')
		echo (" <td><a href='http://$row[0]'>$row[0]</a></td> ");
		else
		echo ("	<td>$row[0]</td>");
		$traffic = conv_byte($row[1]);
		echo ("	<td>$row[1]<br>($traffic)</td>
				<td>$row[2]</td>
			");
		$row = mysql_fetch_array($result);
		$num++;
		echo ("	<td bgcolor='lightyellow'>$num</td>
			");
		if($sel == 'dip' || $sel == 'sip')
		echo (" <td><a href='http://$row[0]'>$row[0]</a></td> ");
		else
		echo ("	<td>$row[0]</td>");
		$traffic = conv_byte($row[1]);
		echo ("	<td>$row[1]<br>($traffic)</td>
				<td>$row[2]</td>
			");
			
	}
	//echo $query;

/*
######################��� ��� END ########################################
*/
	
?>
</table>

<table align=center cellspacing=20  border=0>
	<tr>
		<td><div class=user>
			<? 
				if($mode == "DB")
					echo "�� ����� ��Ŷ: $total_record";
				else if($mode == "LIVE")
					echo "�� �˻��� ��Ŷ: $total_record �߿��� �ߺ��� ���� �Ǿ����ϴ�.";			
			?></div>
		</td>
	</tr>	
<?
$next_block = $block+1;
$prev_block = $block-1;
$newline_rink = 0;

//echo "loop : ".($total_record - $start_record) / $page_per."<br>";
//echo "next : ".$total_record / ($page_per * $link_per)."<br>";

echo "<tr><td colspan=12 align=center >";
if($prev_block < 0){
	echo "<img src = './img/back.jpg' border=0 width='70' height='17'>&nbsp;&nbsp;";
}else{
	echo "<a href = 'body.php?page=0&year=$year&mon=$mon&day=$day&block=$prev_block&sip=$sip&dip=$dip&detail=$detail&mode=$mode&req=not'><img src = './img/back.jpg' border=0 width='70' height='17'></a>&nbsp;&nbsp";		
}



for($i=0; (($total_record - $block * $link_per * $page_per) >  $page_per * $i)   && $i< $link_per ; $i++){
	if(!($newline_link++ % 10) && $newline_rink !=0){
		echo "<br>";
	}
	if($i == $page){
		echo "&nbsp;| $i |&nbsp;";
	}else{
		echo "<a href = 'body.php?page=$i&year=$year&mon=$mon&day=$day&block=$block&sip=$sip&dip=$dip&detail=$detail&mode=$mode&req=not'> | $i |&nbsp;</a>";
	}
}

if($next_block > ($total_record / ($page_per * $link_per))){
	echo "&nbsp;&nbsp;<img src = './img/next.jpg' border=0 width='70' height='17'>";
}else{
	echo "&nbsp;&nbsp;<a href = 'body.php?page=0&year=$year&mon=$mon&day=$day&block=$next_block&sip=$sip&dip=$dip&detail=$detail&mode=$mode&req=not'><img src = './img/next.jpg' border=0 width='70' height='17'></a>";
}
}



else{
?>
	
	
<table align=left>
<tr>
	<td>
		<?
		include("./chart.php");
		?>
	</td>
</tr>
</table>
	
	




<?
}
?>
</td></tr>
</table>
</td>
</tr>
</table>

