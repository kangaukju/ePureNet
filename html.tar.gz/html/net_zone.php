<?php

///////////////////////////
$port = 9000;
//////////////////////////


if( $_POST['agent'] && $_POST['ip'] )
{
	$dest= $_POST['ip'];
				
	$value=explode("agent", $_POST['agent']);
	$NET_REQ = "NET".$value[1]."\0";
	$recv_data;
	$interval = 20;
	$start_time;
	$end_time;


  if(false === $socket = @socket_create(AF_INET, SOCK_STREAM, 0)){
		echo "socket create error<br>";	// !!!!!!!!����!!!!!!!!!!!!!!
	}
	else{		
		if(false === @socket_connect($socket, $dest, $port)){
			echo "socket_connect error<br>";	// !!!!!!!!����!!!!!!!!!!!!!!
		}
		else{			
			if(false === @socket_write ($socket, $NET_REQ, strlen($NET_REQ))){
				echo "socket_write error<br>";	// !!!!!!!!����!!!!!!!!!!!!!!
			}
			else{
				//$start_time = date('is');
				$end_time = time()+$interval;
				socket_set_nonblock($socket);
				while(true){
					if($recv_data = socket_read ($socket, 10) ){
						echo "Y";	// !!!!!!!!����!!!!!!!!!!!!!!
						break;
					}
					else if(time() > $end_time){
						echo "N";
						break;				// !!!!!!!!����!!!!!!!!!!!!!!
					}
					sleep(1);
				}	
			}
		}
	}
}
else{

	echo "N";

}
?>
