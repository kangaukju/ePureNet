<?php include "include/incs.php"; ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<head>
	<title> �ּ��߰� </title>
	<meta http-equiv="Content-Type" content="text/html; charset=euc-kr" />
	<script language="javascript" src="/js/common.js"></script>
	<link rel="stylesheet" href="/css/common.css" type="text/css" />
</head>

<body>
<table width="300px" border="0" cellpadding="5" cellspacing="0" align="center" class="pop_texts">
<tr>
<td class="paddingT30" colspan="2" style="border-right:0;">+ �ּ��߰�</td>
</tr>
<tr>
<th>����</th>
<td>	
	<select id="where" class="selectbox">
		<option value="">����</option>
		<option value="url">URL</option>
		<option value="keyword">KEYWORD</option>
		<option value="ip">IP</option>
	</select>
</td>
</tr>
<tr>
<th>ī�װ���</th>
<td>
	<select id="category" class="selectbox">
		<option value="">����</option>
		<?php
		$category_list=mysql_query ("SELECT * FROM catagory");
		while ($category=@mysql_fetch_array ($category_list)) { ?>
			<option value="<?=$category['no']?>"><?=$category['korean']?></option>
		<?php } ?>
	</select>
</td>
</tr>
<tr>
<th>�ּ�</th>
<td><input type="text" id="address" value="" style="width:220px;" /></td>
</tr>
<tr>
<td colspan="2" align="center" style="border-right:0; border-bottom:0;"><input type="button" value="�߰�" onclick="address_add('<?=$_GET[agent]?>');" /></td>
</tr>
</table>
</body>
</html>