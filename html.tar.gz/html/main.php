<?php include "header.php"; ?>

<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td style="font-size:12px; color:#000; text-align:center; font-weight:bold;">��ü Ʈ���� �� ������</td>
</tr>
<tr>
<td valign="top" style="padding-left:150px;">
	<?
	$year=date("Y", time());
	$mon=date("m", time());

	$database = "statics";
	$connect=mysql_connect($mysql_server,$db_user,$db_password) or die("");
	mysql_select_db($database, $connect) or die ("");

	$qeury="SHOW TABLES";
	$result=mysql_query($qeury);
	$row=@mysql_fetch_array($result);

	while( $agent = @mysql_fetch_array($result) ) {

		$date=$year."-".$mon;
		$qeury="SELECT sum(tbyte), sum(gbyte), sum(mbyte), sum(kbyte), sum(byte), sum(all_acc), sum(deny_acc) FROM ".$agent[0];

		$result1=mysql_query($qeury);

		$row=@mysql_fetch_array($result1);
		$size = $row[0]*1024*1024*1024*1024+$row[1]*1024*1024*1024+$row[2]*1024*1024+$row[3]*1024+$row[4];
		$ALL_TRAFFIC = (int)($size/(1024*1024));
		$ALL_TRAFFICS = (int)($size/(1024*1024));
		$ALL_TRAFFICSD=(int)($ALL_TRAFFICS*(1/100));
		$ALL_TRAFFIC .= " MB";
		$DENY_RATE = (int)(( $row[6] / $row[5] )*100);
		$DENY_RATE .= "%";

		
		echo "<table width='100%' height='60px' border='0' cellpadding='0' cellspacing='0' style='font-size:11px; color:#666;'><tr><td style='color:#ff0000;' valign='top'><strong>".$agent[0]."</strong></td></tr><tr><td valign='top'>- <span style='color:#a9a9a9;'>������( ����Ƚ��/��ü���ӽõ� )</span>: ".$ALL_TRAFFIC."</td></tr><tr><td valign='top'><div style='margin-left:10px; width=".$ALL_TRAFFICSD."; height:10px; background-color:#3d7e3b;'></div></td></tr><tr><td valign='top'>- <span style='color:#a9a9a9;'>��Ʈ���� ( �Ŵ� 1�� ���� )</span>: ".$DENY_RATE."</td></tr></table>";
	}
	?>
</td>
</tr>
</table>

<?php include "footer.php"; ?>
