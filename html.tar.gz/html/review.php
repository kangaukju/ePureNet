<?php
/*
$_POST['agent']="agent1";
$_POST['ip']="211.221.225.34";
$_POST['port']="9000";
$_POST['year']="2008";
$_POST['mon']="1";
*/
if( $_POST['agent'] && $_POST['ip'] && $_POST['port'] && $_POST['year'] && $_POST['mon'])
{	
	$port = $_POST['port'];
	$dest= $_POST['ip'];
	
	$value=explode("agent", $_POST['agent']);	
	
	$REQ = "REV".$value[1]."-".$_POST['year']."-".$_POST['mon']."\0";
	$recv_data;	
	

  if(false === $socket = @socket_create(AF_INET, SOCK_STREAM, 0))
  {
		echo "socket create error<br>";	// !!!!!!!!����!!!!!!!!!!!!!!
	}
	else
	{		
		if(false === @socket_connect($socket, $dest, $port))
		{
			echo "socket_connect error<br>";	// !!!!!!!!����!!!!!!!!!!!!!!
		}
		else
		{			
			if(false === @socket_write ($socket, $REQ, 13))
			{
				echo "socket_write error<br>";	// !!!!!!!!����!!!!!!!!!!!!!!
			}
		}
	}
}

?>
