<?php include "header.php"; ?>
<table width="760px" border="0" cellpadding="0" cellspacing="0" class="bg_center">
<tr height="30px">
<td valign="top"><input type="button" value="�ǽð� �α� ��������" class="cursor" onclick="soket_log('<?=$_GET['agent']?>');" /></td>
</tr>
<tr height="70px">
<td valign="top">
	<form method="get" action="<?=$_SERVER['PHP_SELF']?>">
	<input type="hidden" name="agent" value="<?=$_GET['agent']?>">
	<table width="380px" border="0" cellpadding="5" cellspacing="0" class="C1_table">
	<tr>
	<td>����� IP</td>
	<td colspan="6"><input type="text" name="start_ip" class="search_input" value="<?=$_GET['start_ip']?>" /></td>
	<td rowspan="2" colspan="2"><input type="submit" value="�˻�" class="search_submit" />
	</tr>
	<tr>
	<td>������ IP</td>
	<td colspan="6" colspan="2"><input type="text" name="end_ip" class="search_input" value="<?=$_GET['end_ip']?>" /></td>
	</tr>
	</table>
	</form>
</td>
</tr>
<?php if ($_GET['agent'] && $_GET['log']=="yes") { ?>
	<tr>
	<td valign="top">
		<table width="654px" border="0" cellpadding="5" cellspacing="0" class="CL_table">
		<tr height="40px" valign="top">
		<th>No.</th>
		<th>����� IP</th>
		<th>��Ʈ</th>
		<th>������ IP</th>
		<th>��Ʈ</th>
		<th>url</th>
		<th>��¥</th>
		<th>�ð�</th>
		</tr>
		<?php
		$database=$_GET['agent'];

		$connect=mysql_connect ($mysql_server, $db_user, $db_password);
		mysql_select_db($database, $connect) or die ("DB���� ����");

		$query1="SELECT count(*) FROM live";
		if ($_GET['start_ip']!="" && $_GET['end_ip']!="") {
			$query1="SELECT count(*) FROM live WHERE src_ip='$_GET[start_ip]' AND dest_ip='$_GET[end_ip]'";
		}
		else if ($_GET['start_ip']=="" && $_GET['end_ip']!="") {
			$query1="SELECT count(*) FROM live WHERE dest_ip='$_GET[end_ip]'";
		}
		else if ($_GET['start_ip']!="" && $_GET['end_ip']=="") {
			$query1="SELECT count(*) FROM live WHERE src_ip='$_GET[start_ip]'";
		}
		$result1=mysql_query($query1, $connect);
		$total=@mysql_fetch_array($result1);
		$total=$total["count(*)"];
		$page=30;
		$pagesu=ceil($total/$page);
		$start=($page*$pagenum);
		$query2="SELECT * FROM live LIMIT $start, $page";
		if ($_GET['start_ip']!="" && $_GET['end_ip']!="") {
			$query2="SELECT * FROM live WHERE src_ip='$_GET[start_ip]' AND dest_ip='$_GET[end_ip]' LIMIT $start, $page";
		}
		else if ($_GET['start_ip']=="" && $_GET['end_ip']!="") {
			$query2="SELECT * FROM live WHERE dest_ip='$_GET[end_ip]' LIMIT $start, $page";
		}
		else if ($_GET['start_ip']!="" && $_GET['end_ip']=="") {
			$query2="SELECT * FROM live WHERE src_ip='$_GET[start_ip]' LIMIT $start, $page";
		}
		$result2=mysql_query($query2, $connect);
		$pageviewsu=10;
		$pagegroup=ceil(($pagenum+1)/$pageviewsu);
		$pagestart=($pageviewsu*($pagegroup-1))+1;
		$pageend=$pagestart+$pageviewsu-1;
		$totals=ceil($total/$page)-1;
		if ($_GET['pagenum']=="0" || !$_GET['pagenum']) { $k=$total+1; }
		else { $k=$total-($page*$pagenum)+1; }
		if ($total>0) {
			while ($agent_list=@mysql_fetch_array ($result2)) { ?>
				<tr align="center">
				<td class="borderB"><?=$k?></td>
				<td class="borderB"><?=$agent_list['src_ip']?></td>
				<td class="borderB"><?=$agent_list['src_port']?></td>
				<td class="borderB"><a href="http://<?=$agent_list['dest_ip']?>" target="_blank"><?=$agent_list['dest_ip']?></a></td>
				<td class="borderB"><?=$agent_list['dest_port']?></td>
				<td class="borderB"><?=$agent_list['url']?></td>
				<td class="borderB"><?=$agent_list['date']?></td>
				<td class="borderB"><?=$agent_list['time']?></td>
				</tr>
			<?php 
			$k--;
			} ?>
			<tr>
			<td colspan="8" height="50px" align="center" class="paging">
				<?php
				if ($pagenum) {
					$prevpage=$pagenum-1;
					if($prevpage<0) {
					}
					else {
						echo '<a href='.$_SERVER['PHP_SELF'].'?pagenum='.$prevpage.'&agent='.$_GET['agent'].'&start_ip='.$_GET['start_ip'].'&end_ip='.$_GET['end_ip'].'&log='.$_GET['log'].'>����</a><span> | </span>';
					}
				}
				for ($i=$pagestart; $i<=$pageend; $i++) {
					$j=$i-1;
					if ($pagesu<$i) {
						break;
					}
					if ($j<0) {
					}
					else {
						if ($j==$pagenum) {
							if ($pagenum==0 || ($pagenum+1)==$pagestart) {
							}
							else {
								echo '<span> | </span>';
							}
							echo '<span style="color:#fb4622;"><strong>'.$i.'</strong></span>';
						}
						else {
							if ($i==1 || $i==$pagestart) {
							}
							else {
								echo '<span> | </span>';
							}
							echo '<a href='.$_SERVER['PHP_SELF'].'?pagenum='.$j.'&agent='.$_GET['agent'].'&start_ip='.$_GET['start_ip'].'&end_ip='.$_GET['end_ip'].'&log='.$_GET['log'].'>'.$i.'</a>';
						}
					}
				}
				if (($pagenum+1)!=$pagesu) {
					$nextpage=$pagenum+1;
					if($pagenum+1>$totals) {
					}
					else {
						echo '<span> | </span><a href='.$_SERVER['PHP_SELF'].'?pagenum='.$nextpage.'&agent='.$_GET['agent'].'&start_ip='.$_GET['start_ip'].'&end_ip='.$_GET['end_ip'].'&log='.$_GET['log'].'>����</a>';
					}
				}
				?>
			</td>
			</tr>
		<?php }
		else { ?>
			<tr>
			<td colspan="9" align="center">�˻��� ������ �����ϴ�.</td>
			</tr>
		<?php } ?>
		</table>
	</td>
	</tr>
<?php }
else{
	echo "<tr><td valign='top' style='padding-top:10px; padding-left:10px;'><span style='color:#ff0000; font-size:11px;'></span></td></tr>";
} ?>
</table>
<?php include "footer.php"; ?>
