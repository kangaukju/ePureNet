var request=null;
function createRequest() {
	try {
		 request=null;
		request=new XMLHttpRequest();
	} catch (trymicrosoft) {
		try {
			request=null;
			request=new ActiveXObject("MSXm12.XMLHTTP");
		} catch (othermicrosoft) {
			try {
				request=null;
				request=new ActiveXObject("Microsoft.XMLHTTP");
			} catch (failed) {
				request=null;
			}
		}
	}
	if (request==null) {
		alert("error");
	}
}

var requests=null;
function createRequests() {
	try {
		 requests=null;
		requests=new XMLHttpRequest();
	} catch (trymicrosoft) {
		try {
			requests=null;
			requests=new ActiveXObject("MSXm12.XMLHTTP");
		} catch (othermicrosoft) {
			try {
				requests=null;
				requests=new ActiveXObject("Microsoft.XMLHTTP");
			} catch (failed) {
				requests=null;
			}
		}
	}
	if (requests==null) {
		alert("error");
	}
}

var requestss=null;
function createRequestss() {
	try {
		 requestss=null;
		requestss=new XMLHttpRequest();
	} catch (trymicrosoft) {
		try {
			requestss=null;
			requestss=new ActiveXObject("MSXm12.XMLHTTP");
		} catch (othermicrosoft) {
			try {
				requestss=null;
				requestss=new ActiveXObject("Microsoft.XMLHTTP");
			} catch (failed) {
				requestss=null;
			}
		}
	}
	if (requestss==null) {
		alert("error");
	}
}

var requestd=null;
function createRequestd() {
	try {
		 requestd=null;
		requestd=new XMLHttpRequest();
	} catch (trymicrosoft) {
		try {
			requestd=null;
			requestd=new ActiveXObject("MSXm12.XMLHTTP");
		} catch (othermicrosoft) {
			try {
				requestd=null;
				requestd=new ActiveXObject("Microsoft.XMLHTTP");
			} catch (failed) {
				requestd=null;
			}
		}
	}
	if (requestd==null) {
		alert("error");
	}
}

//�α������� background�� ����(login.php ȣ��)
function login_check() {
	var form=document.getElementById("form");
	var ip=document.getElementById("ip").value;
	var id=document.getElementById("id").value;
	var pass=document.getElementById("pass").value;

	if (ip=="") {
		alert("ip address�� �Է��ϼ���.");
		form.ip.focus();
		return false;
	}
	else if (id=="") {
		alert("id�� �Է��ϼ���.");
		form.id.focus();
		return false;
	}
	else if (pass=="") {
		alert("password�� �Է��ϼ���.");
		form.pass.focus();
		return false;
	}
	else {
		createRequest();
		request.onreadystatechange=function(){
			if(request.readyState==4){
				if (request.status==200) {
					if (request.responseText=="Y") {
						locations("main.php?sms=yes");
					}
					else {
						alert("�߸��� �����Դϴ�!!");
					}
				}
			}
		}
		url="./login.php";
		request.open("POST",url,true);
		request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=utf-8");
		request.send("ip="+encodeURIComponent(ip)+"&id="+encodeURIComponent(id)+"&pass="+encodeURIComponent(pass));
	}
}

function locations(value) {
	location.replace(value);
}

//�α׾ƿ�
function logout_check() {
	createRequest();
	request.onreadystatechange=function(){
		if(request.readyState==4){
			if (request.status==200) {
				locations("index.php");
			}
		}
	}
	url="./logout.php";
	request.open("POST",url,true);
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=utf-8");
	request.send(null);
}

//������ top
function main_tab(value) {
	for (var i=1; i<3; i++) {
		if (value==i) {
			document.getElementById("sub_"+i).style.display="";
		}
		else {
			document.getElementById("sub_"+i).style.display="none";
		}
	}
}

function main_clear() {
	for (var i=1; i<3; i++) {
		document.getElementById("sub_"+i).style.display="none";
	}
}

//agent���� �޾ƿ��� ����
function main_agent(url, value) {
	location.replace(url+"?agent="+value);
}

//���� �׷��� �������� �̵�
function page1_submit(value, url) {
	location.replace(url+".php?agent="+value);
}

//pass check
function pass_check() {
	if (document.form.pass.value!=document.form.re_pass.value) {
		alert("�н����尡 �ٸ��ϴ�.");
		document.form.pass.focus();
		return false;
	}
	else {
		document.form.submit();
	}
}

//��Ʈ��ũ ��ü �߰�
function netobj_add() {
	var netobj=document.getElementById("netobj").value;
	var agent=document.getElementById("agent").value;
	createRequest();
	request.onreadystatechange=function(){
		if(request.readyState==4){
			if (request.status==200) {
				pop_after();
			}
		}
	}
	url="./netobj_add_ok.php";
	request.open("POST",url,true);
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
	request.send("agent="+encodeURIComponent(agent)+"&netobj="+encodeURIComponent(netobj));
}

function pop_after() {
	opener.location.reload();
	self.close();
}

function pop_after_modify(netobj, agent) {
	location.replace("police.php?agent="+agent+"&netobj="+netobj);
}

//��Ʈ��ũ ��ü ����
function netobj_modify(agent, i) {
	var netobj=document.getElementById("netobj_"+i).value;
	var R_netobj=document.getElementById("R_netobj_"+i).value;
	createRequest();
	request.onreadystatechange=function(){
		if(request.readyState==4){
			if (request.status==200) {
				pop_after_modify(netobj, agent);
			}
		}
	}
	url="./netobj_modify_ok.php";
	request.open("POST",url,true);
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
	request.send("agent="+encodeURIComponent(agent)+"&netobj="+encodeURIComponent(netobj)+"&R_netobj="+encodeURIComponent(R_netobj));
}

//��Ʈ��ũ ��ü ����
function netobj_del(agent, i) {
	var R_netobj=document.getElementById("R_netobj_"+i).value;
	createRequest();
	request.onreadystatechange=function(){
		if(request.readyState==4){
			if (request.status==200) {
				document.location.reload();
			}
		}
	}
	url="./netobj_del_ok.php";
	request.open("POST",url,true);
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
	request.send("agent="+encodeURIComponent(agent)+"&R_netobj="+encodeURIComponent(R_netobj));
}

//ȣ��Ʈ �׷� �߰�
function host_add() {
	var host=document.getElementById("host").value;
	var netobj=document.getElementById("netobj").value;
	var agent=document.getElementById("agent").value;
	createRequest();
	request.onreadystatechange=function(){
		if(request.readyState==4){
			if (request.status==200) {
				pop_after();
			}
		}
	}
	url="./host_add_ok.php";
	request.open("POST",url,true);
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
	request.send("agent="+encodeURIComponent(agent)+"&host="+encodeURIComponent(host)+"&netobj="+encodeURIComponent(netobj));
}

//ȣ��Ʈ �׷� ����
function host_modify(agent, i) {
	var R_host=document.getElementById("R_host_"+i).value;
	var host=document.getElementById("host_"+i).value;
	createRequest();
	request.onreadystatechange=function(){
		if(request.readyState==4){
			if (request.status==200) {
				document.location.reload();
			}
		}
	}
	url="./host_modify_ok.php";
	request.open("POST",url,true);
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
	request.send("agent="+encodeURIComponent(agent)+"&R_host="+encodeURIComponent(R_host)+"&host="+encodeURIComponent(host));
}

//ȣ��Ʈ �׷� ����
function host_del(agent, i) {
	var R_host=document.getElementById("R_host_"+i).value;
	createRequest();
	request.onreadystatechange=function(){
		if(request.readyState==4){
			if (request.status==200) {
				document.location.reload();
			}
		}
	}
	url="./host_del_ok.php";
	request.open("POST",url,true);
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
	request.send("agent="+encodeURIComponent(agent)+"&R_host="+encodeURIComponent(R_host));
}

//üũ�ڽ� ����,����
function url_check(This, value, agent, netobj, where, no) {
	if (netobj=="") {
		alert("��Ʈ��ũ ��ü�� �����ϼ���.");
		if (This.checked==true) {
			This.checked=false;
		}
		else {
			This.checked=true;
		}
	}
	else {
		createRequestd();
		requestd.onreadystatechange=function(){
			if(requestd.readyState==4){
				if (requestd.status==200) {
					//document.location.reload();
				}
			}
		}
		if (This.checked==true) {
			url="./check_ok.php";
		}
		else {
			url="./check_no.php";
		}
		requestd.open("POST",url,true);
		requestd.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
		requestd.send("agent="+encodeURIComponent(agent)+"&netobj="+encodeURIComponent(netobj)+"&where="+encodeURIComponent(where)+"&value="+encodeURIComponent(value)+"&no="+encodeURIComponent(no));
	}
}

//ī�װ��� ��ü����
function category_on(agent, netobj, value, where) {
	if (netobj=="") {
		alert("��Ʈ��ũ ��ü�� �����ϼ���.");
	}
	else {
		var deleteok=confirm("��ü���� �Ͻðڽ��ϱ�?");
		if (deleteok==true) {
			createRequest();
			request.onreadystatechange=function(){
				if(request.readyState==4){
					if (request.status==200) {
						category_on_ok(agent, netobj, value, where);
						//document.location.reload();
					}
					else {
						document.getElementById("no_tu").style.display="";
						document.getElementById("no_tu").style.height=document.body.scrollHeight+'px';
						document.getElementById("no_tu").style.width=document.body.scrollWidth+'px';
					}
				}
				else {
					document.getElementById("no_tu").style.display="";
					document.getElementById("no_tu").style.height=document.body.scrollHeight+'px';
					document.getElementById("no_tu").style.width=document.body.scrollWidth+'px';
				}
			}
			url="./category_on.php";
			request.open("POST",url,true);
			request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
			request.send("agent="+encodeURIComponent(agent)+"&netobj="+encodeURIComponent(netobj)+"&value="+encodeURIComponent(value)+"&where="+encodeURIComponent(where));
		}
	}
}

function category_on_ok(agent, netobj, value, where) {
	createRequest();
	request.onreadystatechange=function(){
		if(request.readyState==4){
			if (request.status==200) {
				document.location.reload();
			}
			else {
				document.getElementById("no_tu").style.display="";
				document.getElementById("no_tu").style.height=document.body.scrollHeight+'px';
				document.getElementById("no_tu").style.width=document.body.scrollWidth+'px';
			}
		}
		else {
			document.getElementById("no_tu").style.display="";
			document.getElementById("no_tu").style.height=document.body.scrollHeight+'px';
			document.getElementById("no_tu").style.width=document.body.scrollWidth+'px';
		}
	}
	url="./category_on_ok.php";
	request.open("POST",url,true);
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
	request.send("agent="+encodeURIComponent(agent)+"&netobj="+encodeURIComponent(netobj)+"&value="+encodeURIComponent(value)+"&where="+encodeURIComponent(where));
}

//ī�װ��� ��ü��������
function category_off(agent, netobj, value, where) {
	if (netobj=="") {
		alert("��Ʈ��ũ ��ü�� �����ϼ���.");
	}
	else {
		var deleteok=confirm("��ü���� ���� �Ͻðڽ��ϱ�?");
		if (deleteok==true) {
			createRequest();
			request.onreadystatechange=function(){
				if(request.readyState==4){
					if (request.status==200) {
						document.location.reload();
					}
					else {
						document.getElementById("no_tu").style.display="";
						document.getElementById("no_tu").style.height=document.body.scrollHeight+'px';
						document.getElementById("no_tu").style.width=document.body.scrollWidth+'px';
					}
				}
				else {
					document.getElementById("no_tu").style.display="";
					document.getElementById("no_tu").style.height=document.body.scrollHeight+'px';
					document.getElementById("no_tu").style.width=document.body.scrollWidth+'px';
				}
			}
			url="./category_off.php";
			request.open("POST",url,true);
			request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
			request.send("agent="+encodeURIComponent(agent)+"&netobj="+encodeURIComponent(netobj)+"&value="+encodeURIComponent(value)+"&where="+encodeURIComponent(where));
		}
	}
}

//�ǽð�
var timecheck=true;
function real_time(agent) {
	if (timecheck==true) {
		createRequest();
		request.onreadystatechange=function(){
			if(request.readyState==4){
				if (request.status==200) {
					real_height(request.responseText);
				}
			}
		}
		url="./real_on.php";
		request.open("POST",url,true);
		request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
		request.send("agent="+encodeURIComponent(agent));

		setTimeout('real_time("'+agent+'")', 3000);
	}
}

function real_height(value) {
	var height=value.split("/");

	document.getElementById("cpu").src="img/per_"+height[0]+".gif";
	document.getElementById("mem").src="img/per_"+height[1]+".gif";
	document.getElementById("disk1").src="img/per_"+height[2]+".gif";
	document.getElementById("disk2").src="img/per_"+height[3]+".gif";
}

//��Ʈ��ũ ����
function net_view(ip, agent) {
	timecheck=false;
	createRequest();
	request.onreadystatechange=function(){
		if(request.readyState==4){
			if (request.status==200) {
				timecheck=true;
				setTimeout('real_time("'+agent+'")', 3000);
				if (request.responseText=="N") {
					document.getElementById("no_tu").style.display="none";
					alert("��Ʈ��ũ ���Ⱑ �����Ͽ����ϴ�.");
				}
				else {
					location.reload();
				}
			}
		}
		else {
			document.getElementById("no_tu").style.display="";
			document.getElementById("no_tu").style.height=document.body.scrollHeight+'px';
			document.getElementById("no_tu").style.width=document.body.scrollWidth+'px';
		}
	}
	url="./net_zone.php";
	request.open("POST",url,true);
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
	request.send("ip="+encodeURIComponent(ip)+"&agent="+encodeURIComponent(agent));
}

//�ּ��߰�
function address_add(agent) {
	var where=document.getElementById("where").value;
	var category=document.getElementById("category").value;
	var address=document.getElementById("address").value;
	createRequest();
	request.onreadystatechange=function(){
		if(request.readyState==4){
			if (request.status==200) {
				pop_after();
			}
		}
	}
	url="./address_add_ok.php";
	request.open("POST",url,true);
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
	request.send("agent="+encodeURIComponent(agent)+"&where="+encodeURIComponent(where)+"&category="+encodeURIComponent(category)+"&address="+encodeURIComponent(address));
}

//��å����
function agree(ip, agent, netobj) {
	createRequest();
	request.onreadystatechange=function(){
		if(request.readyState==4){
			if (request.status==200) {
				document.getElementById("no_tu").style.display="none";
				if (request.responseText=="N") {
					alert("��å������ �����Ͽ����ϴ�.");
				}
				else {
				}
			}
		}
		else {
			document.getElementById("no_tu").style.display="";
			document.getElementById("no_tu").style.height=document.body.scrollHeight+'px';
			document.getElementById("no_tu").style.width=document.body.scrollWidth+'px';
		}
	}
	url="./policy_ok.php";
	request.open("POST",url,true);
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
	request.send("ip="+encodeURIComponent(ip)+"&agent="+encodeURIComponent(agent));
}

//���� �α� ��������(ù��° �ð�)
function be_come(agent, ip) {
	var port=9000;
	var year=document.form.year.value;
	var mon=document.form.mon.value;
	createRequest();
	request.onreadystatechange=function(){
		if(request.readyState==4){
			if (request.status==200) {
				if (request.responseText=="No") {
					alert("������ �����ϴ�.");
				}
				else {
					var deleteok=confirm("���� �α� �������µ� "+request.responseText+"�� ���� �ҿ�˴ϴ�.\n\n�������ðڽ��ϱ�?");
					if (deleteok==true) {
						be_comes(agent, ip, port, year, mon);
					}
				}
			}
		}
	}
	url="./req_time.php";
	request.open("POST",url,true);
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
	request.send("agent="+encodeURIComponent(agent)+"&ip="+encodeURIComponent(ip)+"&port="+encodeURIComponent(port)+"&year="+encodeURIComponent(year)+"&mon="+encodeURIComponent(mon));
}

//�����α� �������� (�ι�° ����)
function be_comes(agent, ip, port, year, mon) {
	createRequest();
	request.onreadystatechange=function(){
		if(request.readyState==4){
			if (request.status==200) {
			}
		}
	}
	url="./review.php";
	request.open("POST",url,true);
	request.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=euc-kr");
	request.send("agent="+encodeURIComponent(agent)+"&ip="+encodeURIComponent(ip)+"&port="+encodeURIComponent(port)+"&year="+encodeURIComponent(year)+"&mon="+encodeURIComponent(mon));
}

//left alive
function left(sms, phone) {
	createRequests();
	requests.onreadystatechange=function(){
		if(requests.readyState==4){
			if (requests.status==200) {
				left_come(requests.responseXML, phone);
			}
		}
	}
	url="./left_come.php";
	requests.open("POST",url,true);
	requests.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=utf-8");
	requests.send("sms="+encodeURIComponent(sms));

	setTimeout('left("'+sms+'", "'+phone+'")', 3000);
}

function left_come(xml, phone) {
	var statuss=xml.getElementsByTagName("statuss");
	var sms=xml.getElementsByTagName("sms");
	var left=document.getElementById("left");
	var table="<table width='140px' border='0' cellpadding='1' cellspacing='0' class='left_list'><tr><th width='80px' class='borderR'>Name</th><th width='60px'>Status</th></tr>";

	for (var i=0; i<statuss.length; i++) {
		var img="";
		var agent=statuss[i].getAttribute("agent");
		var alive=statuss[i].getAttribute("alive");
		if (alive==1) {
			img="<img src='img/left_dotgren.gif' />";
		}
		else {
			img="<img src='img/left_dotred.gif' />";
		}

		table=table+"<tr align='center'><td class='borderR'>"+agent+"</td><td>"+img+"</td></tr>";
	}
	table=table+"</table>";
	left.innerHTML=table;

	for (var i=0; i<sms.length; i++) {
		var agent=sms[i].getAttribute("agent");
		var sms_msg=agent;

		createRequestss();
		requestss.onreadystatechange=function(){
			if(requestss.readyState==4){
				if (requestss.status==200) {
				}
			}
		}
		url="./sms.php";
		requestss.open("POST",url,true);
		requestss.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=utf-8");
		requestss.send("sms_msg="+encodeURIComponent(sms_msg));
	}
}

//�׷��� ����
function soket_log(agent) {
	createRequestd();
	requestd.onreadystatechange=function(){
		if(requestd.readyState==4){
			if (requestd.status==200) {
				if (requestd.responseText=="YES") {
					location.replace("P2_log.php?agent="+agent+"&log=yes");
				}
				else {
					location.replace("P2_log.php?agent="+agent);
				}
			}
		}
		else {
			document.getElementById("no_tu").style.display="";
			document.getElementById("no_tu").style.height=document.body.scrollHeight+'px';
			document.getElementById("no_tu").style.width=document.body.scrollWidth+'px';
		}
	}
	url="./graph_soket.php";
	requestd.open("POST",url,true);
	requestd.setRequestHeader("Content-type","application/x-www-form-urlencoded; charset=utf-8");
	requestd.send("agent="+encodeURIComponent(agent));
}