<?php include "header.php"; 
if ($_GET['year']) {
	$database=$_GET['agent'];

	$connect=mysql_connect ($mysql_server, $db_user, $db_password);
	mysql_select_db($database, $connect) or die ("DB���� ����");

	if ($_GET['day']=="1" || $_GET['day']=="2" || $_GET['day']=="3" || $_GET['day']=="4" || $_GET['day']=="5" || $_GET['day']=="6" || $_GET['day']=="7" || $_GET['day']=="8" || $_GET['day']=="9") {
		$table_day="0".$_GET['day'];
	}
	else {
		$table_day=$_GET['day'];
	}
	if ($_GET['time']=="1" || $_GET['time']=="2" || $_GET['time']=="3" || $_GET['time']=="4" || $_GET['time']=="5" || $_GET['time']=="6" || $_GET['time']=="7" || $_GET['time']=="8" || $_GET['time']=="9") {
		$table_time="0".$_GET['time'];
	}
	else {
		$table_time=$_GET['time'];
	}
	$table="AG".$table_day.$table_time;

	$result=mysql_query ("SELECT * FROM $_GET[agent].$table group by dest_ip", $connect);
	//$result=mysql_query ("SELECT distinct src_ip, dest_ip, time  FROM $_GET[agent].$table group by src_ip, dest_ip, time order by time", $connect);

	$filename="List.csv";
	$csv_cont.="No,�����IP,��Ʈ,������IP,��Ʈ,url,��¥,�ð�\n";
	$i=1;
	while ($temp=@mysql_fetch_array ($result)) {
	  $item1=$i;
	  $item2=$temp['src_ip'];
	  $item3=$temp['src_port'];
	  $item4=$temp['dest_ip'];
	  $item5=$temp['dest_port'];
	  $item6=$temp['url'];
	  $item7=$temp['date'];
	  $item8=$temp['time'];
	  $csv_cont.=$item1.",".$item2.",".$item3.",".$item4.",".$item5.",".$item6.",".$item7.",".$item8."\n"; 
	  $i++;
	}
	$fp = fopen("excel/$filename","w") ;
	fwrite($fp,$csv_cont) ;
	fclose($fp) ;
} ?>
<table width="760px" border="0" cellpadding="0" cellspacing="0" class="bg_center">
<tr height="60px">
<td valign="top">
	<table width="380px" border="0" cellpadding="5" cellspacing="0" class="C1_table">
	<tr>
	<td width="110px">��ȸ��¥</td>
	<td align="right">
		<select name="year" class="selectbox">
			<?php $year=date("Y", time()); ?>
			<option value=<?=$year?>><?=$year?></option>
		</select>
	</td>
	<td>��</td>
	<td align="right">
		<select name="mon" class="selectbox">
			<?php $month=date("m", time()); 
			if ($month=="01") {
				$mon=1;
			}
			else if ($month=="02") {
				$mon=2;
			} 
			else if ($month=="03") {
				$mon=3;
			} 
			else if ($month=="04") {
				$mon=4;
			} 
			else if ($month=="05") {
				$mon=5;
			} 
			else if ($month=="06") {
				$mon=6;
			} 
			else if ($month=="07") {
				$mon=7;
			} 
			else if ($month=="08") {
				$mon=8;
			} 
			else if ($month=="09") {
				$mon=9;
			} 
			else {
				$mon=$month;
			} ?>
			<option value=<?=$mon?>><?=$mon?></option>
		</select>
	</td>
	<td>��</td>
	<td align="right">
		<select name="day" class="selectbox" onchange="location.replace('<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&year=<?=$year?>&mon=<?=$mon?>&day='+this.value+'&time=<?=$_GET['time']?>');">
			<option value="">����</option>
			<?php $i=1;
			while ($i<=31) {
				if ($i==$_GET['day']) {
					echo '<option value='.$i.' selected>'.$i.'</option>';
				}
				else {
					echo '<option value='.$i.'>'.$i.'</option>';
				}
				$i++;
			} ?>
		</select>
	</td>
	<td>��</td>
	<td align="right">
		<select name="time" class="selectbox" onchange="location.replace('<?=$_SERVER['PHP_SELF']?>?agent=<?=$_GET['agent']?>&year=<?=$year?>&mon=<?=$mon?>&day=<?=$_GET['day']?>&time='+this.value);">
			<option value="">����</option>
			<?php $i=1;
			while ($i<=24) {
				if ($i==$_GET['time']) {
					echo '<option value='.$i.' selected>'.$i.'</option>';
				}
				else {
					echo '<option value='.$i.'>'.$i.'</option>';
				}
				$i++;
			} ?>
		</select>
	</td>
	<td>��</td>
	</tr>
	</table>
</td>
</tr>
<tr>
<td valign="top" class="paddingL10"><a href="excel/<?=$filename?>" target="_blank"><img src="img/btn_excel.gif" alt="������ �����ϱ�" /></a></td>
</tr>
</table>

<?php include "footer.php"; ?>
