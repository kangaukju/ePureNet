<?php include "include/incs.php";

$table=$_POST['agent']."_netobj";
$table2=$_POST['agent']."_group";
mysql_query ("UPDATE $table SET netobj='$_POST[netobj]' WHERE netobj='$_POST[R_netobj]'", $connect);
mysql_query ("UPDATE $table2 SET netobj='$_POST[netobj]' WHERE netobj='$_POST[R_netobj]'", $connect);
?>