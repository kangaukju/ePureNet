<?php include "header.php";

include("Includes/FusionCharts.php");
include("queryFunction.php");
?>
<table width="760px" border="0" cellpadding="0" cellspacing="0" style="padding-left:10px; font-size:11px;">
<tr>
<td>
<?php
if($_GET['agent']){
	$agent = $_GET['agent'];


	$connect=mysql_connect($mysql_server,$db_user,$db_password) or die("");

	$query = "select sum(size), dest_ip, url from ".$agent.".live group by dest_ip";

	$result = mysql_query($query);

	if($result){
	
		// �׷��� ǥ�� ���
		$col1 = 0;
		while ($row = mysql_fetch_array($result))
		{
			if($row['2']!= "UDP" &&  $row['2']!= "TCP"){
				$arrData[$col1][1] =  $row['2'];
			}else{
				$arrData[$col1][1] =  $row['1'];
			}
			$arrData[$col1++][2] = $row['0'];
		}

	
		$strXML = "<chart caption='$title' numberPrefix='' formatNumberScale='0' rotateValues='1' placeValuesInside='1' decimals='0' >";
		$strCategories = "<categories>";
		$strDataCurr = "<dataset seriesName=''>";
		$strDataPrev = "<dataset seriesName=''>";
		$strXML = "<chart caption='A mount of Traffic at This Moment(Byte)' numberPrefix='' formatNumberScale='0'>";
		foreach ($arrData as $arSubData)
		$strXML .= "<set label='" . $arSubData[1] . "' value='" . $arSubData[2] . "' />";
		$strXML .= "</chart>";
		echo renderChart("./Bar2D.swf", "", $strXML, "productSales", 760, 670, false, false);
	}
}
else{
	echo "<span style='color:#ff0000;'>�ǽð� �˻��� ������ �߻��Ͽ����ϴ�.</span>";
}
?>
</td>
</tr>
</table>

<?php include "footer.php"; ?>