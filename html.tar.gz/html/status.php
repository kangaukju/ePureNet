<?php include "header.php"; 
$no=$_GET['agent']['5'];
$ip=@mysql_fetch_array (mysql_query ("SELECT * FROM status WHERE id='$no'", $connect));
if ($ip['alive']!="1") { ?>
	<table width="100%" border="0" cellpadding="5" cellspacing="0" class="S_table">
	<tr>
	<td align="center"><strong>��� dead �����Դϴ�.</strong></td>
	</tr>
	</table>
<?php }
else { ?>
	<script language="JavaScript">setTimeout("real_time('<?=$_GET[agent]?>')", 3000);</script>
	<table width="100%" border="0" cellpadding="5" cellspacing="0" class="S_table">
	<tr>
	<td>+ <strong><?=$_GET['agent']?></strong></td>
	</tr>
	<?php if ($ip['ip']==$ip['mirror_ip']) { ?>
		<tr>
		<td>ip : <strong><?=$ip['ip']?></strong></td>
		</tr>
	<?php }
	else { ?>
		<tr>
		<td>gateway : <strong><?=$ip['ip']?></strong></td>
		</tr>
		<tr>
		<td>mirror ip : <strong><?=$ip['mirror_ip']?></strong></td>
		</tr>
	<?php } ?>
	<tr>
	<td>
		<table width="600px" border="0" cellpadding="0" cellspacing="0" class="pop_text">
		<tr>
		<td width="150px" align="center">
			CPU
			<div class="status">
				<img src="img/per_0.gif" alt="" id="cpu" />
			</div>
		</td>
		<td width="150px" align="center">
			MEM
			<div class="status">
				<img src="img/per_0.gif" alt="" id="mem" />
			</div>
		</td>
		<td width="150px" align="center">
			DISK1
			<div class="status">
				<img src="img/per_0.gif" alt="" id="disk1" />
			</div>
		</td>
		<td width="150px" align="center">
			DISK2
			<div class="status">
				<img src="img/per_0.gif" alt="" id="disk2" />
			</div>
		</td>
		</tr>
		</table>
	</td>
	</tr>
	<tr>
	<td>&nbsp;</td>
	</tr>
	<tr>
	<td class="paddingT5B5" align="center" bgcolor="#f3f3f3">+ Net_Zone</td>
	</tr>
	<tr>
	<td><img src="img/btn_network.gif" alt="��Ʈ��ũ ����" class="cursor" onclick="net_view('<?=$mysql_server?>', '<?=$_GET['agent']?>');" /></td>
	</tr>
	<tr>
	<td>
		<table width="100%" border="0" cellpadding="0" cellspacing="0">
		<tr>
		<td width="120px" align="center">
			<?php $net_list=@mysql_fetch_array ( mysql_query ("SELECT * FROM status WHERE id='$no'", $connect));
			$net_ips=explode(".", $net_list['mirror_ip']);
			$net_ip=$net_ips[0].".".$net_ips[1].".".$net_ips[2].".";
			$j=1;
			for ($i=0; $i<256; $i++) {
				if ($net_list['net_zone'][$i]=="1") { ?>
					<table border="0" cellpadding="0" cellspacing="0" class="pop_text">
					<tr>
					<td><img src="img/img_alive.gif" alt="" width="75px"/></td>
					</tr>
					<tr>
					<td align="center"><?=$net_ip.$i?></td>
					</tr>
					</table>
					<?php 
					if ($j%6==0) { ?>
						</td>
						</tr>
						<tr>
						<td width="120px">
					<?php }
					else { ?>
						</td>
						<td width="120px">
					<?php }
				$j++;
				}
			} ?>
		</td>
		</tr>
		</table>
	</td>
	</tr>
	</table>
<?php }
include "footer.php"; ?>