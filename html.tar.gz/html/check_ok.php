<?php include "include/incs.php";

$table=$_POST['agent']."_policy";
if ($_POST['where']=="url") {
	$wheres=1;
}
else if ($_POST['where']=="keyword") {
	$wheres=2;
}
else if ($_POST['where']=="ip") {
	$wheres=3;
}
$category=@mysql_fetch_array (mysql_query ("SELECT * FROM $_POST[where] WHERE content='$_POST[value]'", $connect));
mysql_query ("INSERT INTO $table (netobj, type, catagory, no) VALUES ('$_POST[netobj]', '$wheres', '$category[catagory]', '$category[no]')", $connect);
?>